setwd("/Users/laavanyaganesh/Desktop/Adobe Project Submission/Presentation/Final Submission Folder")

pre_post_df <- read.csv("pre-post data.csv")

install.packages("dplyr")
library("dplyr")

# Install
if(!require(devtools)) install.packages("devtools")
devtools::install_github("kassambara/ggpubr")
install.packages("ggpubr")
library("ggpubr")

install.packages("PairedData")
library(PairedData)

# -------------------- AOV
new = pre_post_df %>% group_by(pre_post_df$Pre.Post) %>% summarise(n = mean(AOV, na.rm=T), count = n(),  sd = sd(AOV, na.rm = TRUE))
new

#> new
# A tibble: 2 x 4
#`pre_post_df$Pre.Post`     n count    sd
#<fct>                  <dbl> <int> <dbl>
#  1 Post                    386.    14  47.5
#2 Pre                     373.    14  35.6

ggboxplot(pre_post_df, x = "Pre.Post", y = "AOV", 
          color = "Pre.Post", palette = c("#00AFBB", "#E7B800"),
          order = c("Pre", "Post"),
          ylab = "AOV", xlab = "Groups")

# Subset AOV data before treatment
before <- subset(pre_post_df,  pre_post_df$Pre.Post == "Pre", AOV,
                 drop = TRUE)
# subset AOV data after treatment
after <- subset(pre_post_df, pre_post_df$Pre.Post == "Post", AOV,
                drop = TRUE)

# Plot paired data
pd <- paired(before, after)
plot(pd, type = "profile") + theme_bw()

ggqqplot(before)
ggqqplot(after)


# compute the difference
d <- with(pre_post_df, AOV[pre_post_df$Pre.Post == "Pre"] - AOV[pre_post_df$Pre.Post == "Post"])
# Shapiro-Wilk normality test for the differences
shapiro.test(d) # => p-value = 0.4563
#shapiro.test(d) # => p-value = 0.4563

#Shapiro-Wilk normality test

#data:  d
#W = 0.94287, p-value = 0.4563


# Compute t-test
res <- t.test(before, after, paired = TRUE, alternative = "two.sided")
res

# Compute t-test
res_1 <- t.test(AOV ~ pre_post_df$Pre.Post, data = pre_post_df, paired = TRUE, alternative = "two.sided")
res_1   # 0.4711


# data:  AOV by pre_post_df$Pre.Post
# t = 0.74224, df = 13, p-value = 0.4711
# alternative hypothesis: true difference in means is not equal to 0
# 95 percent confidence interval:
#   -23.74593  48.60307
# sample estimates:
#   mean of the differences 
# 12.42857 

# Compute t-test
res_2 <- t.test(AOV ~ pre_post_df$Pre.Post, data = pre_post_df, paired = FALSE, alternative = "two.sided")
res_2   # 0.4409

# Welch Two Sample t-test
# 
# data:  AOV by pre_post_df$Pre.Post
# t = 0.78365, df = 24.099, p-value = 0.4409
# alternative hypothesis: true difference in means is not equal to 0
# 95 percent confidence interval:
#   -20.29757  45.15472
# sample estimates:
#   mean in group Post  mean in group Pre 
# 385.7143           373.2857 

# Not significantly different
#AOV increasing in POST

# Compute unparametric-test
# Compute t-test
res <- wilcox.test(AOV ~ pre_post_df$Pre.Post, data = pre_post_df, paired = TRUE, alternative="two.sided")
res

# Wilcoxon signed rank test
# 
# data:  AOV by pre_post_df$Pre.Post
# V = 64, p-value = 0.5016
# alternative hypothesis: true location shift is not equal to 0

res <- wilcox.test(AOV ~ pre_post_df$Pre.Post, data = pre_post_df, paired = FALSE, alternative="two.sided")
res


# Wilcoxon rank sum test with continuity correction
# 
# data:  AOV by pre_post_df$Pre.Post
# W = 123, p-value = 0.2602
# alternative hypothesis: true location shift is not equal to 0

# -------------------- CTR
new_1 = pre_post_df %>% group_by(pre_post_df$Pre.Post) %>% summarise(n = mean(CTR, na.rm=T), count = n(),  sd = sd(CTR, na.rm = TRUE))
new_1

# > new_1
# # A tibble: 2 x 4
# `pre_post_df$Pre.Post`      n count      sd
# <fct>                   <dbl> <int>   <dbl>
#   1 Post                   0.0119    14 0.00150
# 2 Pre                    0.0121    14 0.00149

ggboxplot(pre_post_df, x = "Pre.Post", y = "CTR", 
          color = "Pre.Post", palette = c("#00AFBB", "#E7B800"),
          order = c("Pre", "Post"),
          ylab = "CTR", xlab = "Groups")

#CTR decreasing

before_2 <- subset(pre_post_df,  pre_post_df$Pre.Post == "Pre", CTR,
                   drop = TRUE)
# subset AOV data after treatment
after_2 <- subset(pre_post_df, pre_post_df$Pre.Post == "Post",CTR,
                  drop = TRUE)
# Plot paired data
pd_2 <- paired(before_2, after_2)
plot(pd_2, type = "profile") + theme_bw()

ggqqplot(before_2)
ggqqplot(after_2)


# compute the difference
d_2 <- with(pre_post_df, CTR[pre_post_df$Pre.Post == "Pre"] - CTR[pre_post_df$Pre.Post == "Post"])
# Shapiro-Wilk normality test for the differences
shapiro.test(d_2) # => p-value = 0.6958
#W = 0.95835
#Normal

# > shapiro.test(d_2) # => p-value = 0.6958
# 
# Shapiro-Wilk normality test
# 
# data:  d_2
# W = 0.95835, p-value = 0.6958

# Compute t-test
res_6 <- t.test(before_2, after_2, paired = TRUE, alternative = "two.sided")
res_6

# Compute t-test
res_7 <- t.test(CTR ~ pre_post_df$Pre.Post, data = pre_post_df, paired = TRUE, alternative = "two.sided")
res_7   # 0.682

# Paired t-test
# 
# data:  CTR by pre_post_df$Pre.Post
# t = -0.41911, df = 13, p-value = 0.682
# alternative hypothesis: true difference in means is not equal to 0
# 95 percent confidence interval:
#   -0.0013188509  0.0008902795
# sample estimates:
#   mean of the differences 
# -0.0002142857 

# Compute t-test
res_8 <- t.test(CTR ~ pre_post_df$Pre.Post, data = pre_post_df, paired = FALSE, alternative = "two.sided")
res_8   # 0.7077

# Welch Two Sample t-test
# 
# data:  CTR by pre_post_df$Pre.Post
# t = -0.37915, df = 25.996, p-value = 0.7077
# alternative hypothesis: true difference in means is not equal to 0
# 95 percent confidence interval:
#   -0.0013760361  0.0009474647
# sample estimates:
#   mean in group Post  mean in group Pre 
# 0.01186429         0.01207857 

# Not significantly different

# Compute t-test
res <- wilcox.test(CTR ~ pre_post_df$Pre.Post, data = pre_post_df, paired = FALSE, alternative="two.sided")
res


# Wilcoxon rank sum test with continuity correction
# 
# data:  CTR by pre_post_df$Pre.Post
# W = 88.5, p-value = 0.6791
# alternative hypothesis: true location shift is not equal to 0

res <- wilcox.test(CTR ~ pre_post_df$Pre.Post, data = pre_post_df, paired = TRUE, alternative="two.sided")
res
# res

# Wilcoxon signed rank test with continuity correction
# 
# data:  CTR by pre_post_df$Pre.Post
# V = 40, p-value = 0.7267
# alternative hypothesis: true location shift is not equal to 0

# -------------------- CPC
new_2 = pre_post_df %>% group_by(pre_post_df$Pre.Post) %>% summarise(n = mean(CPC, na.rm=T), count = n(),  sd = sd(CPC, na.rm = TRUE))
new_2

# # A tibble: 2 x 4
# `pre_post_df$Pre.Post`     n count    sd
# <fct>                  <dbl> <int> <dbl>
#   1 Post                    4.54    14 0.268
# 2 Pre                     4.49    14 0.359

ggboxplot(pre_post_df, x = "Pre.Post", y = "CPC", 
          color = "Pre.Post", palette = c("#00AFBB", "#E7B800"),
          order = c("Pre", "Post"),
          ylab = "CPC", xlab = "Pre.Post")

#CPC is decreasing

before_1 <- subset(pre_post_df,  pre_post_df$Pre.Post == "Pre", CPC,
                   drop = TRUE)
# subset AOV data after treatment
after_1 <- subset(pre_post_df, pre_post_df$Pre.Post == "Post",CPC,
                  drop = TRUE)
# Plot paired data
pd_1 <- paired(before_1, after_1)
plot(pd_1, type = "profile") + theme_bw()

library(ggpubr)
ggqqplot(before_1)
ggqqplot(after_1)


# compute the difference
d_1 <- with(pre_post_df, CPC[pre_post_df$Pre.Post == "Pre"] - CPC[pre_post_df$Pre.Post == "Post"])
# Shapiro-Wilk normality test for the differences
shapiro.test(d_1) # => p-value = 0.4105
# Normal
#W = 0.93938

# Shapiro-Wilk normality test
# 
# data:  d_1
# W = 0.93938, p-value = 0.4105

# Compute t-test
res_3 <- t.test(before_1, after_1, paired = TRUE, alternative = "two.sided")
res_3

# Compute t-test
res_4 <- t.test(CPC ~ pre_post_df$Pre.Post, data = pre_post_df, paired = TRUE, alternative = "two.sided")
res_4   # 0.4577

# Paired t-test
# 
# data:  before_1 and after_1
# t = -0.76545, df = 13, p-value = 0.4577
# alternative hypothesis: true difference in means is not equal to 0
# 95 percent confidence interval:
#   -0.2184198  0.1041341
# sample estimates:
#   mean of the differences 
# -0.05714286 

# Compute t-test
res_5 <- t.test(CPC ~ pre_post_df$Pre.Post, data = pre_post_df, paired = FALSE, alternative = "two.sided")
res_5   # 0.6376

# Welch Two Sample t-test
# 
# data:  CPC by pre_post_df$Pre.Post
# t = 0.47704, df = 24.054, p-value = 0.6376
# alternative hypothesis: true difference in means is not equal to 0
# 95 percent confidence interval:
#   -0.1900526  0.3043383
# sample estimates:
#   mean in group Post  mean in group Pre 
# 4.542857           4.485714 
# Not significantly different

res <- wilcox.test(CPC ~ pre_post_df$Pre.Post, data = pre_post_df, paired = TRUE, alternative="two.sided")
res

# Wilcoxon signed rank test with continuity correction
# 
# data:  CPC by pre_post_df$Pre.Post
# V = 34.5, p-value = 0.506
# alternative hypothesis: true location shift is not equal to 0

res <- wilcox.test(CPC ~ pre_post_df$Pre.Post, data = pre_post_df, paired = FALSE, alternative="two.sided")
res

# Wilcoxon rank sum test with continuity correction
# 
# data:  CPC by pre_post_df$Pre.Post
# W = 105, p-value = 0.7638
# alternative hypothesis: true location shift is not equal to 0


# -------------------- ROAS
new_3 = pre_post_df %>% group_by(pre_post_df$Pre.Post) %>% summarise(n = mean(ROAS, na.rm=T), count = n(),  sd = sd(ROAS, na.rm = TRUE))
new_3

# # A tibble: 2 x 4
# `pre_post_df$Pre.Post`     n count    sd
# <fct>                  <dbl> <int> <dbl>
#   1 Post                    8.85    14  1.77
# 2 Pre                     8.43    14  1.55

# ROAS is decreasing

ggboxplot(pre_post_df, x = "Pre.Post", y = "ROAS", 
          color = "Pre.Post", palette = c("#00AFBB", "#E7B800"),
          order = c("Pre", "Post"),
          ylab = "ROAS", xlab = "Pre.Post")

before_4 <- subset(pre_post_df,  pre_post_df$Pre.Post == "Pre", ROAS,
                   drop = TRUE)
# subset AOV data after treatment
after_4 <- subset(pre_post_df, pre_post_df$Pre.Post == "Post",ROAS,
                  drop = TRUE)
# Plot paired data
pd_4 <- paired(before_4, after_4)
plot(pd_4, type = "profile") + theme_bw()

library(ggpubr)
ggqqplot(before_4)
ggqqplot(after_4)


# compute the difference
d_4 <- with(pre_post_df, ROAS[pre_post_df$Pre.Post == "Pre"] - ROAS[pre_post_df$Pre.Post == "Post"])
# Shapiro-Wilk normality test for the differences
shapiro.test(d_4) # => p-value = 0.4913
#Normal
#W = 0.94537

# Shapiro-Wilk normality test
# 
# data:  d_4
# W = 0.94537, p-value = 0.4913

# Compute t-test
res_12 <- t.test(before_4, after_4, paired = TRUE, alternative = "two.sided")
res_12

# Compute t-test
res_13 <- t.test(ROAS ~ pre_post_df$Pre.Post, data = pre_post_df, paired = TRUE, alternative="two.sided")
res_13   # 0.4963

# Paired t-test
# 
# data:  ROAS by pre_post_df$Pre.Post
# t = 0.69997, df = 13, p-value = 0.4963
# alternative hypothesis: true difference in means is not equal to 0
# 95 percent confidence interval:
#   -0.8752666  1.7142907
# sample estimates:
#   mean of the differences 
# 0.419512 


# Compute t-test
res_14 <- t.test(ROAS ~ pre_post_df$Pre.Post, data = pre_post_df, paired = FALSE, alternative="two.sided")
res_14   # 0.5109

# Welch Two Sample t-test
# 
# data:  ROAS by pre_post_df$Pre.Post
# t = 0.66678, df = 25.522, p-value = 0.5109
# alternative hypothesis: true difference in means is not equal to 0
# 95 percent confidence interval:
#   -0.8749164  1.7139405
# sample estimates:
#   mean in group Post  mean in group Pre 
# 8.852289           8.432777 

#Not significantly different

res <- wilcox.test(ROAS ~ pre_post_df$Pre.Post, data = pre_post_df, paired = TRUE, alternative="two.sided")
res

# Wilcoxon signed rank test
# 
# data:  ROAS by pre_post_df$Pre.Post
# V = 57, p-value = 0.8077
# alternative hypothesis: true location shift is not equal to 0


res <- wilcox.test(ROAS ~ pre_post_df$Pre.Post, data = pre_post_df, paired = FALSE, alternative="two.sided")
res
# 
# Wilcoxon rank sum test
# 
# data:  ROAS by pre_post_df$Pre.Post
# W = 109, p-value = 0.6347
# alternative hypothesis: true location shift is not equal to 0

# -------------------- Revenue
new_4 = pre_post_df %>% group_by(pre_post_df$Pre.Post) %>% summarise(n = mean(Revenue, na.rm=T), count = n(),  sd = sd(Revenue, na.rm = TRUE))
new_4
# # A tibble: 2 x 4
# `pre_post_df$Pre.Post`      n count     sd
# <fct>                   <dbl> <int>  <dbl>
#   1 Post                   85737.    14 21760.
# 2 Pre                    77585.    14 16332.

ggboxplot(pre_post_df, x = "Pre.Post", y = "Revenue", 
          color = "Pre.Post", palette = c("#00AFBB", "#E7B800"),
          order = c("Pre", "Post"),
          ylab = "Revenue", xlab = "Pre.Post")

before_6 <- subset(pre_post_df,  pre_post_df$Pre.Post == "Pre", Revenue,
                   drop = TRUE)
# subset AOV data after treatment
after_6 <- subset(pre_post_df, pre_post_df$Pre.Post == "Post", Revenue,
                  drop = TRUE)
# Plot paired data
library(PairedData)
pd_6 <- paired(before_6, after_6)
plot(pd_6, type = "profile") + theme_bw()


library(ggpubr)
ggqqplot(before_6)
ggqqplot(after_6)


# compute the difference
d_6 <- with(pre_post_df, Revenue[pre_post_df$Pre.Post == "Pre"] - Revenue[pre_post_df$Pre.Post == "Post"])
# Shapiro-Wilk normality test for the differences
shapiro.test(d_6) # => p-value = 0.04695
#W = 0.87346
#Not normal
# Shapiro-Wilk normality test
# 
# data:  d_6
# W = 0.87346, p-value = 0.04695

# Compute t-test
res_18 <- t.test(before_6, after_6, paired = TRUE, alternative = "two.sided")
res_18

# Compute t-test
res_19 <- t.test(Revenue ~ pre_post_df$Pre.Post, data = pre_post_df, paired = TRUE, alternative="two.sided")
res_19   # 0.3452

# Paired t-test
# 
# data:  Revenue by pre_post_df$Pre.Post
# t = 0.97945, df = 13, p-value = 0.3452
# alternative hypothesis: true difference in means is not equal to 0
# 95 percent confidence interval:
#   -9828.704 26132.374
# sample estimates:
#   mean of the differences 
# 8151.835 

# Compute t-test
res_20 <- t.test(Revenue ~ pre_post_df$Pre.Post, data = pre_post_df, paired = FALSE, alternative="two.sided")
res_20   # 0.2733

# Welch Two Sample t-test
# 
# data:  Revenue by pre_post_df$Pre.Post
# t = 1.1211, df = 24.118, p-value = 0.2733
# alternative hypothesis: true difference in means is not equal to 0
# 95 percent confidence interval:
#   -6851.824 23155.495
# sample estimates:
#   mean in group Post  mean in group Pre 
# 85736.98           77585.14 

# Not significantly different
library(rcompanion)
pre_post_df$Revenue_Normal <- transformTukey(pre_post_df$Revenue, start = -10, end = 10, int = 0.025, plotit = TRUE,verbose = FALSE, statistic = 1)

res_21 <- t.test(Revenue_Normal ~ pre_post_df$Pre.Post, data = pre_post_df, paired = TRUE, alternative="two.sided")
res_21   # 0.3813

# Paired t-test
# 
# data:  Revenue_Normal by pre_post_df$Pre.Post
# t = 0.90622, df = 13, p-value = 0.3813
# alternative hypothesis: true difference in means is not equal to 0
# 95 percent confidence interval:
#   -0.003573985  0.008738978
# sample estimates:
#   mean of the differences 
# 0.002582496 

res_22 <- t.test(Revenue_Normal ~ pre_post_df$Pre.Post, data = pre_post_df, paired = FALSE, alternative="two.sided")
res_22   # 0.313

# Welch Two Sample t-test
# 
# data:  Revenue_Normal by pre_post_df$Pre.Post
# t = 1.0294, df = 25.324, p-value = 0.313
# alternative hypothesis: true difference in means is not equal to 0
# 95 percent confidence interval:
#   -0.002580886  0.007745879
# sample estimates:
#   mean in group Post  mean in group Pre 
# -0.5675611         -0.5701435 

# Not significantly different

res <- wilcox.test(Revenue ~ pre_post_df$Pre.Post, data = pre_post_df, paired = TRUE, alternative="two.sided")
res

# Wilcoxon signed rank test
# 
# data:  Revenue by pre_post_df$Pre.Post
# V = 60, p-value = 0.6698
# alternative hypothesis: true location shift is not equal to 0

res <- wilcox.test(Revenue ~ pre_post_df$Pre.Post, data = pre_post_df, paired = FALSE, alternative="two.sided")
res

# Wilcoxon rank sum test
# 
# data:  Revenue by pre_post_df$Pre.Post
# W = 122, p-value = 0.2852
# alternative hypothesis: true location shift is not equal to 0

install.packages("lubridate")
library(lubridate)
transform(pre_post_df, Date = as.Date(as.character(Date), "%Y%m%d"))
pre_post_df$DOW <- as.Date(pre_post_df$Date, "%m/%d/%Y")
pre_post_df$DOW_1 <- wday(pre_post_df$DOW, label=TRUE)




# -------------------- Conversions
new_5 = pre_post_df %>% group_by(pre_post_df$Pre.Post) %>% summarise(n = mean(Conversions, na.rm=T), count = n(),  sd = sd(Conversions, na.rm = TRUE))
new_5

# > new_5
# # A tibble: 2 x 4
# `pre_post_df$Pre.Post`     n count    sd
# <fct>                  <dbl> <int> <dbl>
#   1 Post                    223.    14  52.7
# 2 Pre                     207.    14  34.6

ggboxplot(pre_post_df, x = "Pre.Post", y = "Conversions", 
          color = "Pre.Post", palette = c("#00AFBB", "#E7B800"),
          order = c("Pre", "Post"),
          ylab = "Conversions", xlab = "Groups")

before_10 <- subset(pre_post_df,  pre_post_df$Pre.Post == "Pre", Conversions,
                   drop = TRUE)
# subset AOV data after treatment
after_10 <- subset(pre_post_df, pre_post_df$Pre.Post == "Post",Conversions,
                  drop = TRUE)
# Plot paired data
library(PairedData)
pd_10 <- paired(before_10, after_10)
plot(pd_10, type = "profile") + theme_bw()

library(ggpubr)
ggqqplot(before_10)
ggqqplot(after_10)


# compute the difference
d_10 <- with(pre_post_df, Conversions[pre_post_df$Pre.Post == "Pre"] - Conversions[pre_post_df$Pre.Post == "Post"])
# Shapiro-Wilk normality test for the differences
shapiro.test(d_10) # => p-value = 0.08077
#Not Normal
#W = 0.88998


# Shapiro-Wilk normality test
# 
# data:  d_10
# W = 0.88998, p-value = 0.08077


# Compute t-test
res_32 <- t.test(before_10, after_10, paired = TRUE, alternative = "two.sided")
res_32 # 0.344

# Paired t-test
# 
# data:  before_10 and after_10
# t = -0.98199, df = 13, p-value = 0.344
# alternative hypothesis: true difference in means is not equal to 0
# 95 percent confidence interval:
#   -51.59543  19.34808
# sample estimates:
#   mean of the differences 
# -16.12367 

# Compute t-test
res_33 <- t.test(Conversions ~ pre_post_df$Pre.Post, data = pre_post_df, paired = TRUE, alternative="two.sided")
res_33   # 0.344

# Paired t-test
# 
# data:  Conversions by pre_post_df$Pre.Post
# t = 0.98199, df = 13, p-value = 0.344
# alternative hypothesis: true difference in means is not equal to 0
# 95 percent confidence interval:
#   -19.34808  51.59543
# sample estimates:
#   mean of the differences 
# 16.12367 

# Not significantly different

# Compute t-test
res_34 <- t.test(Conversions ~ pre_post_df$Pre.Post, data = pre_post_df, paired = FALSE, alternative="two.sided")
res_34   # 0.3491

# Welch Two Sample t-test
# 
# data:  Conversions by pre_post_df$Pre.Post
# t = 0.95622, df = 22.446, p-value = 0.3491
# alternative hypothesis: true difference in means is not equal to 0
# 95 percent confidence interval:
#   -18.80555  51.05290
# sample estimates:
#   mean in group Post  mean in group Pre 
# 223.1866           207.0629 

library(rcompanion)
pre_post_df$Conversions_Normal <- transformTukey(pre_post_df$Conversions, start = -10, end = 10, int = 0.025, plotit = TRUE,verbose = FALSE, statistic = 1)

res_35 <- t.test(Conversions_Normal ~ pre_post_df$Pre.Post, data = pre_post_df, paired = TRUE, alternative="two.sided")
res_35   # 0.4515

res_36 <- t.test(Conversions_Normal ~ pre_post_df$Pre.Post, data = pre_post_df, paired = FALSE, alternative="two.sided")
res_36   # 0.4677


# -------------------- Impressions
new_6 = pre_post_df %>% group_by(pre_post_df$Pre.Post) %>% summarise(n = mean(Impressions, na.rm=T), count = n(),  sd = sd(Impressions, na.rm = TRUE))
new_6

# > new_6
# # A tibble: 2 x 4
# `pre_post_df$Pre.Post`       n count     sd
# <fct>                    <dbl> <int>  <dbl>
#   1 Post                   179985.    14 14535.
# 2 Pre                    171011.    14 12495.

ggboxplot(pre_post_df, x = "Pre.Post", y = "Impressions", 
          color = "Pre.Post", palette = c("#00AFBB", "#E7B800"),
          order = c("Pre", "Post"),
          ylab = "Impressions", xlab = "Groups")

before_9 <- subset(pre_post_df,  pre_post_df$Pre.Post == "Pre", Impressions,
                   drop = TRUE)
# subset AOV data after treatment
after_9 <- subset(pre_post_df, pre_post_df$Pre.Post == "Post",Impressions,
                  drop = TRUE)
# Plot paired data
library(PairedData)
pd_9 <- paired(before_9, after_9)
plot(pd_9, type = "profile") + theme_bw()

library(ggpubr)
ggqqplot(before_9)
ggqqplot(after_9)


# compute the difference
d_9 <- with(pre_post_df, Impressions[pre_post_df$Pre.Post == "Pre"] - Impressions[pre_post_df$Pre.Post == "Post"])
# Shapiro-Wilk normality test for the differences
shapiro.test(d_9) # => p-value = 0.9819
#Normal

# Shapiro-Wilk normality test
# 
# data:  d_9
# W = 0.98136, p-value = 0.9819

# Compute t-test
res_29 <- t.test(before_9, after_9, paired = TRUE, alternative = "two.sided")
res_29

# Paired t-test
# 
# data:  before_9 and after_9
# t = -2.021, df = 13, p-value = 0.06437
# alternative hypothesis: true difference in means is not equal to 0
# 95 percent confidence interval:
#   -18565.1448    618.7162
# sample estimates:
#   mean of the differences 
# -8973.214

# Compute t-test
res_30 <- t.test(Impressions ~ pre_post_df$Pre.Post, data = pre_post_df, paired = TRUE, alternative="two.sided")
res_30   # 0.06437

# Paired t-test
# 
# data:  Impressions by pre_post_df$Pre.Post
# t = 2.021, df = 13, p-value = 0.06437
# alternative hypothesis: true difference in means is not equal to 0
# 95 percent confidence interval:
#   -618.7162 18565.1448
# sample estimates:
#   mean of the differences 
# 8973.214 

# Compute t-test
res_31 <- t.test(Impressions ~ pre_post_df$Pre.Post, data = pre_post_df, paired = FALSE, alternative="two.sided")
res_31   # 0.09189

# Welch Two Sample t-test
# 
# data:  Impressions by pre_post_df$Pre.Post
# t = 1.7517, df = 25.427, p-value = 0.09189
# alternative hypothesis: true difference in means is not equal to 0
# 95 percent confidence interval:
#   -1568.154 19514.583
# sample estimates:
#   mean in group Post  mean in group Pre 
# 179984.6           171011.4 

# -------------------- Clicks
new_7 = pre_post_df %>% group_by(pre_post_df$Pre.Post) %>% summarise(n = mean(Clicks, na.rm=T), count = n(),  sd = sd(Clicks, na.rm = TRUE))
new_7

# # A tibble: 2 x 4
# `pre_post_df$Pre.Post`     n count    sd
# <fct>                  <dbl> <int> <dbl>
#   1 Post                   2142.    14  373.
# 2 Pre                    2068.    14  313.

ggboxplot(pre_post_df, x = "Pre.Post", y = "Clicks", 
          color = "Pre.Post", palette = c("#00AFBB", "#E7B800"),
          order = c("Pre", "Post"),
          ylab = "Clicks", xlab = "Groups")

before_8 <- subset(pre_post_df,  pre_post_df$Pre.Post == "Pre", Clicks,
                   drop = TRUE)
# subset AOV data after treatment
after_8 <- subset(pre_post_df, pre_post_df$Pre.Post == "Post",Clicks,
                  drop = TRUE)
# Plot paired data
library(PairedData)
pd_8 <- paired(before_8, after_8)
plot(pd_8, type = "profile") + theme_bw()

library(ggpubr)
ggqqplot(before_8)
ggqqplot(after_8)


# compute the difference
d_8 <- with(pre_post_df, Clicks[pre_post_df$Pre.Post == "Pre"] - Clicks[pre_post_df$Pre.Post == "Post"])
# Shapiro-Wilk normality test for the differences
shapiro.test(d_8) # => p-value = 0.8757
#Normal
#W = 0.96993

# Shapiro-Wilk normality test
# 
# data:  d_8
# W = 0.96993, p-value = 0.8757

# Compute t-test
res_26 <- t.test(before_8, after_8, paired = TRUE, alternative = "two.sided")
res_26

# Compute t-test
res_27 <- t.test(Clicks ~ pre_post_df$Pre.Post, data = pre_post_df, paired = TRUE,alternative = "two.sided")
res_27   # 0.5471

# Paired t-test
# 
# data:  Clicks by pre_post_df$Pre.Post
# t = 0.61824, df = 13, p-value = 0.5471
# alternative hypothesis: true difference in means is not equal to 0
# 95 percent confidence interval:
#   -186.5339  336.0962
# sample estimates:
#   mean of the differences 
# 74.78116 

# Compute t-test
res_28 <- t.test(Clicks ~ pre_post_df$Pre.Post, data = pre_post_df, paired = FALSE,alternative = "two.sided")
res_28   # 0.5703

# Welch Two Sample t-test
# 
# data:  Clicks by pre_post_df$Pre.Post
# t = 0.57511, df = 25.232, p-value = 0.5703
# alternative hypothesis: true difference in means is not equal to 0
# 95 percent confidence interval:
#   -192.8948  342.4571
# sample estimates:
#   mean in group Post  mean in group Pre 
# 2142.456           2067.674

# Not significantly different

# -------------------- Conv..Rate
new_8 = pre_post_df %>% group_by(pre_post_df$Pre.Post) %>% summarise(n = mean(Conv..Rate, na.rm=T), count = n(),  sd = sd(Conv..Rate, na.rm = TRUE))
new_8
# 
# # A tibble: 2 x 4
# `pre_post_df$Pre.Post`     n count     sd
# <fct>                  <dbl> <int>  <dbl>
#   1 Post                   0.104    14 0.0135
# 2 Pre                    0.100    14 0.0112

ggboxplot(pre_post_df, x = "Pre.Post", y = "Conv..Rate", 
          color = "Pre.Post", palette = c("#00AFBB", "#E7B800"),
          order = c("Pre", "Post"),
          ylab = "Conv..Rate", xlab = "Pre.Post")

before_5 <- subset(pre_post_df,  pre_post_df$Pre.Post == "Pre", Conv..Rate,
                   drop = TRUE)
# subset AOV data after treatment
after_5 <- subset(pre_post_df, pre_post_df$Pre.Post == "Post",Conv..Rate,
                  drop = TRUE)
# Plot paired data
library(PairedData)
pd_5 <- paired(before_5, after_5)
plot(pd_5, type = "profile") + theme_bw()

library(ggpubr)
ggqqplot(before_5)
ggqqplot(after_5)


# compute the difference
d_5 <- with(pre_post_df, Conv..Rate[pre_post_df$Pre.Post == "Pre"] - Conv..Rate[pre_post_df$Pre.Post == "Post"])
# Shapiro-Wilk normality test for the differences
shapiro.test(d_5) # => p-value = 0.9325
#Normal
#W = 0.97471
# Shapiro-Wilk normality test
# 
# data:  d_5
# W = 0.97471, p-value = 0.9325

# Compute t-test
res_15 <- t.test(before_5, after_5, paired = TRUE, alternative = "two.sided")
res_15

# Compute t-test
res_16 <- t.test(Conv..Rate ~ pre_post_df$Pre.Post, data = pre_post_df, paired = TRUE, alternative="two.sided")
res_16   # 0.5039

# Paired t-test
# 
# data:  Conv..Rate by pre_post_df$Pre.Post
# t = 0.6875, df = 13, p-value = 0.5039
# alternative hypothesis: true difference in means is not equal to 0
# 95 percent confidence interval:
#   -0.006909139  0.013359139
# sample estimates:
#   mean of the differences 
# 0.003225 


# Compute t-test
res_17 <- t.test(Conv..Rate ~ pre_post_df$Pre.Post, data = pre_post_df, paired = FALSE, alternative="two.sided")
res_17   # 0.4967

# Welch Two Sample t-test
# 
# data:  Conv..Rate by pre_post_df$Pre.Post
# t = 0.68976, df = 25.159, p-value = 0.4967
# alternative hypothesis: true difference in means is not equal to 0
# 95 percent confidence interval:
#   -0.006401362  0.012851362
# sample estimates:
#   mean in group Post  mean in group Pre 
# 0.103725           0.100500 


# -------------------- CPA
new_9 = pre_post_df %>% group_by(pre_post_df$Pre.Post) %>% summarise(n = mean(CPA, na.rm=T), count = n(),  sd = sd(CPA, na.rm = TRUE))
new_9
# 
# # A tibble: 2 x 4
# `pre_post_df$Pre.Post`     n count    sd
# <fct>                  <dbl> <int> <dbl>
#   1 Post                    44.7    14  7.69
# 2 Pre                     45.1    14  5.97

ggboxplot(pre_post_df, x = "Pre.Post", y = "CPA", 
          color = "Pre.Post", palette = c("#00AFBB", "#E7B800"),
          order = c("Pre", "Post"),
          ylab = "CPA", xlab = "Pre.Post")

before_3 <- subset(pre_post_df,  pre_post_df$Pre.Post == "Pre", CPA,
                   drop = TRUE)
# subset AOV data after treatment
after_3 <- subset(pre_post_df, pre_post_df$Pre.Post == "Post",CPA,
                  drop = TRUE)
# Plot paired data
library(PairedData)
pd_3 <- paired(before_3, after_3)
plot(pd_3, type = "profile") + theme_bw()

library(ggpubr)
ggqqplot(before_3)
ggqqplot(after_3)


# compute the difference
d_3 <- with(pre_post_df, CPA[pre_post_df$Pre.Post == "Pre"] - CPA[pre_post_df$Pre.Post == "Post"])
# Shapiro-Wilk normality test for the differences
shapiro.test(d_3) # => p-value = 0.4809
#Normal
#W = 0.94463

# Shapiro-Wilk normality test
# 
# data:  d_3
# W = 0.94463, p-value = 0.4809


# Compute t-test
res_9 <- t.test(before_3, after_3, paired = TRUE, alternative = "two.sided")
res_9

# Compute t-test
res_10 <- t.test(CPA ~ pre_post_df$Pre.Post, data = pre_post_df, paired = TRUE, alternative="two.sided")
res_10   # 0.8493

# Paired t-test
# 
# data:  CPA by pre_post_df$Pre.Post
# t = -0.19384, df = 13, p-value = 0.8493
# alternative hypothesis: true difference in means is not equal to 0
# 95 percent confidence interval:
#   -5.220186  4.360534
# sample estimates:
#   mean of the differences 
# -0.4298264 

# Compute t-test
res_11 <- t.test(CPA ~ pre_post_df$Pre.Post, data = pre_post_df, paired = FALSE, alternative="two.sided")
res_11   # 0.8701

# Welch Two Sample t-test
# 
# data:  CPA by pre_post_df$Pre.Post
# t = -0.16521, df = 24.507, p-value = 0.8701
# alternative hypothesis: true difference in means is not equal to 0
# 95 percent confidence interval:
#   -5.793703  4.934050
# sample estimates:
#   mean in group Post  mean in group Pre 
# 44.68356           45.11339 

 #Not significantly different


# -------------------- Costs
new_10 = pre_post_df %>% group_by(pre_post_df$Pre.Post) %>% summarise(n = mean(Cost, na.rm=T), count = n(),  sd = sd(Cost, na.rm = TRUE))
new_10

# # A tibble: 2 x 4
# `pre_post_df$Pre.Post`     n count    sd
# <fct>                  <dbl> <int> <dbl>
#   1 Post                   9719.    14 1664.
# 2 Pre                    9224.    14 1230.

ggboxplot(pre_post_df, x = "Pre.Post", y = "Cost", 
          color = "Pre.Post", palette = c("#00AFBB", "#E7B800"),
          order = c("Pre", "Post"),
          ylab = "Cost", xlab = "Groups")

before_7 <- subset(pre_post_df,  pre_post_df$Pre.Post == "Pre", Cost,
                   drop = TRUE)
# subset AOV data after treatment
after_7 <- subset(pre_post_df, pre_post_df$Pre.Post == "Post",Cost,
                  drop = TRUE)
# Plot paired data
library(PairedData)
pd_7 <- paired(before_7, after_7)
plot(pd_7, type = "profile") + theme_bw()

library(ggpubr)
ggqqplot(before_7)
ggqqplot(after_7)


# compute the difference
d_7 <- with(pre_post_df, Cost[pre_post_df$Pre.Post == "Pre"] - Cost[pre_post_df$Pre.Post == "Post"])
# Shapiro-Wilk normality test for the differences
shapiro.test(d_7) # => p-value = 0.5135
#Normal
# W = 0.94688

# Shapiro-Wilk normality test
# 
# data:  d_7
# W = 0.94688, p-value = 0.5135


# Compute t-test
res_23 <- t.test(before_7, after_7, paired = TRUE, alternative = "two.sided")
res_23

# Compute t-test
res_24 <- t.test(Cost ~ pre_post_df$Pre.Post, data = pre_post_df, paired = TRUE, alternative="two.sided")
res_24   # 0.3991

# Paired t-test
# 
# data:  Cost by pre_post_df$Pre.Post
# t = 0.87195, df = 13, p-value = 0.3991
# alternative hypothesis: true difference in means is not equal to 0
# 95 percent confidence interval:
#   -731.8966 1722.5413
# sample estimates:
#   mean of the differences 
# 495.3224 


# Compute t-test
res_25 <- t.test(Cost ~ pre_post_df$Pre.Post, data = pre_post_df, paired = FALSE, alternative="two.sided")
res_25   # 0.3794

# Welch Two Sample t-test
# 
# data:  Cost by pre_post_df$Pre.Post
# t = 0.89563, df = 23.943, p-value = 0.3794
# alternative hypothesis: true difference in means is not equal to 0
# 95 percent confidence interval:
#   -646.2442 1636.8889
# sample estimates:
#   mean in group Post  mean in group Pre 
# 9719.387           9224.065 


write.csv(pre_post_df,"Interaction_Analysis.csv")

inter <- read.csv("Interaction_analysis.csv")

new_interaction = pre_post_df %>% group_by(pre_post_df$DOW_1) %>% summarise(n = mean(Revenue, na.rm=T), count = n(),  sd = sd(Revenue, na.rm = TRUE), total = sum(Revenue, na.rm=T))
colnames(new_interaction)[1] <- "Day_Of_Week"
library(ggplot2)

Pre_df <- pre_post_df[which(pre_post_df$Pre.Post =='Pre'),]
Post_df <- pre_post_df[which(pre_post_df$Pre.Post =='Post'),]

new_interaction_8 = Pre_df %>% group_by(Pre_df$DOW_1) %>% summarise(n = mean(Revenue, na.rm=T), count = n(),  sd = sd(Revenue, na.rm = TRUE), total = sum(Revenue, na.rm=T))
colnames(new_interaction_8)[1] <- "Day_Of_Week"

new_interaction_9 = Post_df %>% group_by(Post_df$DOW_1) %>% summarise(n = mean(Revenue, na.rm=T), count = n(),  sd = sd(Revenue, na.rm = TRUE), total = sum(Revenue, na.rm=T))
colnames(new_interaction_9)[1] <- "Day_Of_Week"

ggplot(data=new_interaction_9, aes(x=Day_Of_Week, y=total)) +
  geom_bar(stat="identity", fill="steelblue")+
  geom_text(aes(label=total), vjust=1.6, color="white", size=3.5)+
  theme_minimal()

ggplot(data=new_interaction_8, aes(x=Day_Of_Week, y=total)) +
  geom_bar(stat="identity", fill="steelblue")+
  geom_text(aes(label=total), vjust=1.6, color="white", size=3.5)+
  theme_minimal()


inter$Split <- ifelse(inter$DOW_1=='Sun' | inter$DOW_1=='Sat', "Weekend", "Weekday")
inter$Split_1 <- ifelse(inter$DOW_1=='Sun' | inter$DOW_1=='Sat'| inter$DOW_1=='Fri', "Weekend", "Weekday")

new_interaction_1 = inter %>% group_by(inter$Split) %>% summarise(n = mean(Revenue, na.rm=T), count = n(),  sd = sd(Revenue, na.rm = TRUE), total = sum(Revenue, na.rm=T))
new_interaction_2 = inter %>% group_by(inter$Split_1) %>% summarise(n = mean(Revenue, na.rm=T), count = n(),  sd = sd(Revenue, na.rm = TRUE), total = sum(Revenue, na.rm=T))
colnames(new_interaction_1)[1] <- "Week_Split"
colnames(new_interaction_2)[1] <- "Week_Split"

ggplot(data=new_interaction_1, aes(x=Week_Split, y=total)) +
  geom_bar(stat="identity", fill="steelblue")+
  geom_text(aes(label=total), vjust=1.6, color="white", size=3.5)+
  theme_minimal()

ggplot(data=new_interaction_2, aes(x=Week_Split, y=total)) +
  geom_bar(stat="identity", fill="steelblue")+
  geom_text(aes(label=total), vjust=1.6, color="white", size=3.5)+
  theme_minimal()

#------------------------------------- Pre Post Weekday Weekend Analysis
Weekday_Data <- inter[which(inter$Split =='Weekday'),]
Weekend_Data <- inter[ which(inter$Split =='Weekend'),]
Weekday_Data_1 <- inter[ which(inter$Split_1 =='Weekday'),]
Weekend_Data_1 <-inter[ which(inter$Split_1 =='Weekend'),]

new_interaction_3 = Weekday_Data %>% group_by(Weekday_Data$Pre.Post) %>% summarise(n = mean(Revenue, na.rm=T), count = n(),  sd = sd(Revenue, na.rm = TRUE), total = sum(Revenue, na.rm=T))
new_interaction_4 = Weekend_Data %>% group_by(Weekend_Data$Pre.Post) %>% summarise(n = mean(Revenue, na.rm=T), count = n(),  sd = sd(Revenue, na.rm = TRUE), total = sum(Revenue, na.rm=T))
new_interaction_5 = Weekday_Data_1 %>% group_by(Weekday_Data_1$Pre.Post) %>% summarise(n = mean(Revenue, na.rm=T), count = n(),  sd = sd(Revenue, na.rm = TRUE), total = sum(Revenue, na.rm=T))
new_interaction_6 = Weekend_Data_1 %>% group_by(Weekend_Data_1$Pre.Post) %>% summarise(n = mean(Revenue, na.rm=T), count = n(),  sd = sd(Revenue, na.rm = TRUE), total = sum(Revenue, na.rm=T))

colnames(new_interaction_3)[1] <- "Pre_Post_Split"
colnames(new_interaction_4)[1] <- "Pre_Post_Split"
colnames(new_interaction_5)[1] <- "Pre_Post_Split"
colnames(new_interaction_6)[1] <- "Pre_Post_Split"

ggplot(data=new_interaction_3, aes(x=Pre_Post_Split, y=total)) +
  geom_bar(stat="identity", fill="steelblue")+
  geom_text(aes(label=total), vjust=1.6, color="white", size=3.5)+
  theme_minimal()

ggplot(data=new_interaction_4, aes(x=Pre_Post_Split, y=total)) +
  geom_bar(stat="identity", fill="steelblue")+
  geom_text(aes(label=total), vjust=1.6, color="white", size=3.5)+
  theme_minimal()

ggplot(data=new_interaction_5, aes(x=Pre_Post_Split, y=total)) +
  geom_bar(stat="identity", fill="steelblue")+
  geom_text(aes(label=total), vjust=1.6, color="white", size=3.5)+
  theme_minimal()

ggplot(data=new_interaction_6, aes(x=Pre_Post_Split, y=total)) +
  geom_bar(stat="identity", fill="steelblue")+
  geom_text(aes(label=total), vjust=1.6, color="white", size=3.5)+
  theme_minimal()



#--------- Fri as a weekday, weekday 2 sample ttest
# Subset AOV data before treatment
before_pre <- subset(Weekday_Data,  Weekday_Data$Pre.Post == "Pre", Revenue,
                 drop = TRUE)
# subset AOV data after treatment
after_post <- subset(Weekday_Data, Weekday_Data$Pre.Post == "Post", Revenue,
                drop = TRUE)

# Plot paired data
pd <- paired(before_pre, after_post)
plot(pd, type = "profile") + theme_bw()

ggqqplot(before_pre)
ggqqplot(after_post)


# compute the difference
d <- with(Weekday_Data, Revenue[Weekday_Data$Pre.Post == "Pre"] - Revenue[Weekday_Data$Pre.Post == "Post"])
# Shapiro-Wilk normality test for the differences
shapiro.test(d) # => p-value = 0.5389
#Normal
#W=0.94287
# 
# Shapiro-Wilk normality test
# 
# data:  d
# W = 0.93872, p-value = 0.5389

# Compute t-test
res <- t.test(before_pre, after_post, paired = TRUE, alternative = "two.sided")
res

# Compute t-test
res_1 <- t.test(Revenue ~ Weekday_Data$Pre.Post, data = Weekday_Data, paired = TRUE, alternative = "two.sided")
res_1   # 0.4096

# Paired t-test
# 
# data:  Revenue by Weekday_Data$Pre.Post
# t = 0.86479, df = 9, p-value = 0.4096
# alternative hypothesis: true difference in means is not equal to 0
# 95 percent confidence interval:
#   -10724.75  23999.11
# sample estimates:
#   mean of the differences 
# 6637.181 

# Compute t-test
res_2 <- t.test(Revenue ~ Weekday_Data$Pre.Post, data = Weekday_Data, paired = FALSE, alternative = "two.sided")
res_2   # 0.3607

# Welch Two Sample t-test
# 
# data:  Revenue by Weekday_Data$Pre.Post
# t = 0.94032, df = 16.402, p-value = 0.3607
# alternative hypothesis: true difference in means is not equal to 0
# 95 percent confidence interval:
#   -8296.274 21570.636
# sample estimates:
#   mean in group Post  mean in group Pre 
# 84509.35           77872.17 

# Not significantly different



#--------- Fri as a weekday, weekend 2 sample ttest
# Subset AOV data before treatment
before_pre <- subset(Weekend_Data,  Weekend_Data$Pre.Post == "Pre", Revenue,
                     drop = TRUE)
# subset AOV data after treatment
after_post <- subset(Weekend_Data, Weekend_Data$Pre.Post == "Post", Revenue,
                     drop = TRUE)

# Plot paired data
pd <- paired(before_pre, after_post)
plot(pd, type = "profile") + theme_bw()

ggqqplot(before_pre)
ggqqplot(after_post)


# compute the difference
d <- with(Weekend_Data, Revenue[Weekend_Data$Pre.Post == "Pre"] - Revenue[Weekend_Data$Pre.Post == "Post"])
# Shapiro-Wilk normality test for the differences
shapiro.test(d) # => p-value = 0.1234
#Normal
#W=0.94287

# Shapiro-Wilk normality test
# 
# data:  d
# W = 0.81099, p-value = 0.1234


# Compute t-test
res <- t.test(before_pre, after_post, paired = TRUE, alternative = "two.sided")
res

# Compute t-test
res_1 <- t.test(Revenue ~ Weekend_Data$Pre.Post, data = Weekend_Data, paired = TRUE, alternative = "two.sided")
res_1   # 0.6599
# 
# Paired t-test
# 
# data:  Revenue by Weekend_Data$Pre.Post
# t = 0.48652, df = 3, p-value = 0.6599
# alternative hypothesis: true difference in means is not equal to 0
# 95 percent confidence interval:
#   -66153.40  90030.34
# sample estimates:
#   mean of the differences 
# 11938.47

# Compute t-test
res_2 <- t.test(Revenue ~ Weekend_Data$Pre.Post, data = Weekend_Data, paired = FALSE, alternative = "two.sided")
res_2   # 0.5842
# 
# Welch Two Sample t-test
# 
# data:  Revenue by Weekend_Data$Pre.Post
# t = 0.58004, df = 5.6637, p-value = 0.5842
# alternative hypothesis: true difference in means is not equal to 0
# 95 percent confidence interval:
#   -39158.27  63035.21
# sample estimates:
#   mean in group Post  mean in group Pre 
# 88806.04           76867.57 

# Not significantly different



#--------- Fri as a weekend, weekday 2 sample ttest
# Subset AOV data before treatment
before_pre <- subset(Weekday_Data_1,  Weekday_Data_1$Pre.Post == "Pre", Revenue,
                     drop = TRUE)
# subset AOV data after treatment
after_post <- subset(Weekday_Data_1, Weekday_Data_1$Pre.Post == "Post", Revenue,
                     drop = TRUE)

# Plot paired data
pd <- paired(before_pre, after_post)
plot(pd, type = "profile") + theme_bw()

ggqqplot(before_pre)
ggqqplot(after_post)


# compute the difference
d <- with(Weekday_Data_1, Revenue[Weekday_Data_1$Pre.Post == "Pre"] - Revenue[Weekday_Data_1$Pre.Post == "Post"])
# Shapiro-Wilk normality test for the differences
shapiro.test(d) # => p-value = 0.3476
#Normal
#W=0.94287
# 
# Shapiro-Wilk normality test
# 
# data:  d
# W = 0.90908, p-value = 0.3476


# Compute t-test
res <- t.test(before_pre, after_post, paired = TRUE, alternative = "two.sided")
res

# Compute t-test
res_1 <- t.test(Revenue ~ Weekday_Data_1$Pre.Post, data = Weekday_Data_1, paired = TRUE, alternative = "two.sided")
res_1   # 0.1939

# Paired t-test
# 
# data:  Revenue by Weekday_Data_1$Pre.Post
# t = 1.4368, df = 7, p-value = 0.1939
# alternative hypothesis: true difference in means is not equal to 0
# 95 percent confidence interval:
#   -7748.366 31747.018
# sample estimates:
#   mean of the differences 
# 11999.33 

# Compute t-test
res_2 <- t.test(Revenue ~ Weekday_Data_1$Pre.Post, data = Weekday_Data_1, paired = FALSE, alternative = "two.sided")
res_2   # 0.1695

# Welch Two Sample t-test
# 
# data:  Revenue by Weekday_Data_1$Pre.Post
# t = 1.4606, df = 12.125, p-value = 0.1695
# alternative hypothesis: true difference in means is not equal to 0
# 95 percent confidence interval:
#   -5879.959 29878.611
# sample estimates:
#   mean in group Post  mean in group Pre 
# 87115.55           75116.23 


# Not significantly different



#--------- Fri as a weekend, weekend 2 sample ttest
# Subset AOV data before treatment
before_pre <- subset(Weekend_Data_1,  Weekend_Data_1$Pre.Post == "Pre", Revenue,
                     drop = TRUE)
# subset AOV data after treatment
after_post <- subset(Weekend_Data_1, Weekend_Data_1$Pre.Post == "Post", Revenue,
                     drop = TRUE)

# Plot paired data
pd <- paired(before_pre, after_post)
plot(pd, type = "profile") + theme_bw()

ggqqplot(before_pre)
ggqqplot(after_post)


# compute the difference
d <- with(Weekend_Data_1, Revenue[Weekend_Data_1$Pre.Post == "Pre"] - Revenue[Weekend_Data_1$Pre.Post == "Post"])
# Shapiro-Wilk normality test for the differences
shapiro.test(d) # => p-value = 0.001752
#Normal
#W=0.94287

# Shapiro-Wilk normality test
# 
# data:  d
# W = 0.74433, p-value = 0.01752

Weekend_Data_1$Revenue_Normal <- transformTukey(Weekend_Data_1$Revenue, start = -10, end = 10, int = 0.025, plotit = TRUE,verbose = FALSE, statistic = 1)

# Compute t-test
res <- t.test(before_pre, after_post, paired = TRUE, alternative = "two.sided")
res

# Compute t-test
res_1 <- t.test(Revenue_Normal ~ Weekend_Data_1$Pre.Post, data = Weekend_Data_1, paired = TRUE, alternative = "two.sided")
res_1   # 0.8848
# 
# Paired t-test
# 
# data:  Revenue_Normal by Weekend_Data_1$Pre.Post
# t = 0.15245, df = 5, p-value = 0.8848
# alternative hypothesis: true difference in means is not equal to 0
# 95 percent confidence interval:
#   -4.377245  4.929176
# sample estimates:
#   mean of the differences 
# 0.2759658 

# Compute t-test
res_2 <- t.test(Revenue_Normal ~ Weekend_Data_1$Pre.Post, data = Weekend_Data_1, paired = FALSE, alternative = "two.sided")
res_2   # 0.857

# Welch Two Sample t-test
# 
# data:  Revenue_Normal by Weekend_Data_1$Pre.Post
# t = 0.18498, df = 9.8844, p-value = 0.857
# alternative hypothesis: true difference in means is not equal to 0
# 95 percent confidence interval:
#   -3.053341  3.605272
# sample estimates:
#   mean in group Post  mean in group Pre 
# 29.75672           29.48076 

# Not significantly different


# regression of Revenue with other variables
Pre_Data <- pre_post_df[which(pre_post_df$Pre.Post =='Pre'),]
Post_Data <- pre_post_df[which(pre_post_df$Pre.Post =='Post'),]

# Fit our regression model
sat.mod_1 <- lm(Revenue ~ CTR + CPC + CPA + AOV + ROAS + factor(DOW_1), # regression formula
                data=Pre_Data) # data set
# Summarize and print the results
summary(sat.mod_1) # show regression coefficients table

# 
# Call:
#   lm(formula = Revenue ~ CTR + CPC + CPA + AOV + ROAS + factor(DOW_1), 
#      data = Pre_Data)
# 
# Residuals:
#   1       2       3       4       5       6       7       8       9      10      11      12      13      14 
# 1515.5 -1639.8  -638.5   796.6  -102.2 -1977.0 -1092.8 -1515.5  1639.8   638.5  -796.6   102.2  1977.0  1092.8 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)  
# (Intercept)       60125.2    87229.8   0.689   0.5619  
# CTR             4340895.1  1464547.4   2.964   0.0975 .
# CPC              -12632.1    10910.4  -1.158   0.3665  
# CPA               -1508.1      944.5  -1.597   0.2514  
# AOV                 294.3      145.9   2.017   0.1812  
# ROAS              -2388.5     5446.3  -0.439   0.7038  
# factor(DOW_1).L    1209.4     3974.8   0.304   0.7897  
# factor(DOW_1).Q   11943.4     4814.7   2.481   0.1313  
# factor(DOW_1).C   -5511.7     2937.5  -1.876   0.2014  
# factor(DOW_1)^4    7038.8     3494.4   2.014   0.1816  
# factor(DOW_1)^5  -10644.1     5658.1  -1.881   0.2007  
# factor(DOW_1)^6   -6938.6     7198.0  -0.964   0.4368  
# ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 3338 on 2 degrees of freedom
# Multiple R-squared:  0.9936,	Adjusted R-squared:  0.9582 
# F-statistic: 28.11 on 11 and 2 DF,  p-value: 0.03484

sat.mod_2 <- lm(Revenue ~ Impressions + Conversions + Clicks + Cost, # regression formula
                data=Pre_Data) # data set
# Summarize and print the results
summary(sat.mod_2) # show regression coefficients table

# 
# Call:
#   lm(formula = Revenue ~ Impressions + Conversions + Clicks + Cost, 
#      data = Pre_Data)
# 
# Residuals:
#   Min       1Q   Median       3Q      Max 
# -10422.7  -3807.5   -654.9   3479.6  13652.6 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept) -2.492e+04  3.533e+04  -0.705 0.498365    
# Impressions  1.467e-01  2.298e-01   0.638 0.539086    
# Conversions  5.068e+02  1.030e+02   4.923 0.000821 ***
#   Clicks      -1.359e+01  1.875e+01  -0.725 0.487026    
# Cost         6.205e-02  3.414e+00   0.018 0.985894    
# ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 7802 on 9 degrees of freedom
# Multiple R-squared:  0.842,	Adjusted R-squared:  0.7718 
# F-statistic: 11.99 on 4 and 9 DF,  p-value: 0.001186


# Fit our regression model
sat.mod_3 <- lm(Revenue ~ CTR + CPC + CPA + AOV + ROAS + factor(DOW_1), # regression formula
                data=Post_Data) # data set
# Summarize and print the results
summary(sat.mod_3) # show regression coefficients table
# 
# Call:
#   lm(formula = Revenue ~ CTR + CPC + CPA + AOV + ROAS + factor(DOW_1), 
#      data = Post_Data)
# 
# Residuals:
#   15      16      17      18      19      20      21      22      23      24      25      26      27      28 
# 1838.4 -3341.0  4544.3  2167.4  -931.2   389.1  -430.5 -1838.4  3341.0 -4544.3 -2167.4   931.2  -389.1   430.5 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)
# (Intercept)      475739.2   323219.4   1.472    0.279
# CTR             5625421.0  2399556.3   2.344    0.144
# CPC               12734.1    24456.8   0.521    0.655
# CPA              -13180.4     7526.5  -1.751    0.222
# AOV                1527.4      790.2   1.933    0.193
# ROAS             -58150.7    35946.5  -1.618    0.247
# factor(DOW_1).L   20051.8    13076.1   1.533    0.265
# factor(DOW_1).Q   13587.1     7040.1   1.930    0.193
# factor(DOW_1).C    9338.4     9388.5   0.995    0.425
# factor(DOW_1)^4    9671.3     5945.7   1.627    0.245
# factor(DOW_1)^5   21183.5    16068.5   1.318    0.318
# factor(DOW_1)^6    8569.6     8357.2   1.025    0.413
# 
# Residual standard error: 6410 on 2 degrees of freedom
# Multiple R-squared:  0.9866,	Adjusted R-squared:  0.9132 
# F-statistic: 13.44 on 11 and 2 DF,  p-value: 0.07126



sat.mod_4<- lm(Revenue ~ Impressions + Conversions+ Conv..Rate + Clicks + Cost, # regression formula
                data=Pre_Data) # data set
# Summarize and print the results
summary(sat.mod_4) # show regression coefficients table

# 
# Call:
#   lm(formula = Revenue ~ Impressions + Conversions + Conv..Rate + 
#        Clicks + Cost, data = Pre_Data)
# 
# Residuals:
#   Min       1Q   Median       3Q      Max 
# -10412.2  -3758.7   -594.8   3446.1  13675.3 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)
# (Intercept) -2.956e+04  1.435e+05  -0.206    0.842
# Impressions  1.472e-01  2.441e-01   0.603    0.563
# Conversions  4.853e+02  6.533e+02   0.743    0.479
# Conv..Rate   4.505e+04  1.345e+06   0.033    0.974
# Clicks      -1.140e+01  6.831e+01  -0.167    0.872
# Cost         5.889e-02  3.622e+00   0.016    0.987
# 
# Residual standard error: 8274 on 8 degrees of freedom
# Multiple R-squared:  0.842,	Adjusted R-squared:  0.7433 
# F-statistic: 8.529 on 5 and 8 DF,  p-value: 0.004589
