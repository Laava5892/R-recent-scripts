setwd("/Users/laavanyaganesh/Desktop/Adobe Project Submission/Presentation/Final Submission Folder")

ClicksG0 <- read.csv("ClicksGreaterThan0.csv")
RPCWithout0 <- read.csv("RPC_without0.csv") 

library(rcompanion)
RPCWithout0$RPC_Normal <- transformTukey(RPCWithout0$RPC, start = -10, end = 10, int = 0.025, plotit = TRUE,verbose = FALSE, statistic = 1)
# 
# lambda      W Shapiro.p.value
# 399  -0.05 0.9948       0.0003887
# 
# if (lambda >  0){TRANS = x ^ lambda} 
# if (lambda == 0){TRANS = log(x)} 
# if (lambda <  0){TRANS = -1 * x ^ lambda}
write.csv(RPCWithout0, "RPCWithout0.csv")


new = ClicksG0 %>% group_by(query_length) %>% summarise(avgRPC = mean(RPC, na.rm=T), count = n(), total=sum(RPC, na.rm=T))
new
new_1 = ClicksG0 %>% group_by(query_length) %>% summarise(avgRPC = mean(RPC, na.rm=T))# count = n())
new_1
plot(new_1)


df1 = ClicksG0 %>%
  group_by(query_length) %>%
  filter(!(abs(RPC - median(RPC)) > 2*sd(RPC))) %>%
  summarise(avgRPC = mean(RPC, na.rm=T), count = n(), total=sum(RPC, na.rm=T))

plot(df1)


sat.mod <- lm(RPC ~ query_length, # regression formula
              data=ClicksG0) # data set
# Summarize and print the results
summary(sat.mod) # show regression coefficients table


# Call:
#   lm(formula = RPC ~ query_length, data = ClicksG0)
# 
# Residuals:
#   Min     1Q Median     3Q    Max 
# -3.196 -2.266 -1.956 -0.488 98.354 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)    1.3367     0.3406   3.924 8.85e-05 ***
#   query_length   0.3098     0.1229   2.520   0.0118 *  
#   ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 6.747 on 3818 degrees of freedom
# Multiple R-squared:  0.00166,	Adjusted R-squared:  0.001399 
# F-statistic:  6.35 on 1 and 3818 DF,  p-value: 0.01178

ClicksG0$query_length_greater_than_4 <- 1L * (ClicksG0$query_length > 4)


sat.mod_2 <- lm(RPC ~ query_length + query_length_greater_than_4, # regression formula
                data=ClicksG0) # data set
# Summarize and print the results
summary(sat.mod_2) # show regression coefficients table

# 
# Call:
#   lm(formula = RPC ~ query_length + query_length_greater_than_4, 
#      data = ClicksG0)
# 
# Residuals:
#   Min     1Q Median     3Q    Max 
# -2.930 -2.407 -1.885 -0.456 98.638 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)                   0.8398     0.3826   2.195 0.028208 *  
#   query_length                  0.5225     0.1438   3.633 0.000284 ***
#   query_length_greater_than_4  -2.2106     0.7775  -2.843 0.004489 ** 
#   ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 6.741 on 3817 degrees of freedom
# Multiple R-squared:  0.00377,	Adjusted R-squared:  0.003248 
# F-statistic: 7.223 on 2 and 3817 DF,  p-value: 0.0007397

ClicksG0$CPC_Normal <- transformTukey(ClicksG0$CPC, start = -10, end = 10, int = 0.025, plotit = TRUE,verbose = FALSE, statistic = 1)
# lambda      W Shapiro.p.value
# 412  0.275 0.9968       2.718e-07
# 
# if (lambda >  0){TRANS = x ^ lambda} 
# if (lambda == 0){TRANS = log(x)} 
# if (lambda <  0){TRANS = -1 * x ^ lambda} 

write.csv(ClicksG0, "CPC_NORMAL.csv")


new = ClicksG0 %>% group_by(query_length) %>% summarise(avgCPC = mean(CPC, na.rm=T), count = n(), total=sum(CPC, na.rm=T))
new
new_1 = ClicksG0 %>% group_by(query_length) %>% summarise(avgCPC = mean(CPC, na.rm=T))# count = n())
new_1
plot(new_1)


df1 = ClicksG0 %>%
  group_by(query_length) %>%
  filter(!(abs(CPC - median(CPC)) > 2*sd(CPC))) %>%
  summarise(avgCPC = mean(CPC, na.rm=T), count = n(), total=sum(CPC, na.rm=T))

df2 = ClicksG0 %>%
  group_by(query_length) %>%
  filter(!(abs(CPC - median(CPC)) > 2*sd(CPC))) %>%
  summarise(avgCPC = mean(CPC, na.rm=T))#count = n(), total=sum(CPC, na.rm=T))

plot(df2)


sat.mod <- lm(CPC ~ query_length, # regression formula
              data=ClicksG0) # data set
# Summarize and print the results
summary(sat.mod) # show regression coefficients table

# Call:
#   lm(formula = CPC ~ query_length, data = ClicksG0)
# 
# Residuals:
#   Min      1Q  Median      3Q     Max 
# -14.415  -6.222  -2.637   3.910  78.978 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)    3.8604     0.4493   8.591   <2e-16 ***
#   query_length   2.0107     0.1622  12.398   <2e-16 ***
#   ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 8.901 on 3818 degrees of freedom
# Multiple R-squared:  0.0387,	Adjusted R-squared:  0.03845 
# F-statistic: 153.7 on 1 and 3818 DF,  p-value: < 2.2e-16

#ClicksG0$query_length_greater_than_4 <- 1L * (ClicksG0$query_length > 4)


sat.mod_2 <- lm(CPC ~ query_length + query_length_greater_than_4, # regression formula
                data=ClicksG0) # data set
# Summarize and print the results
summary(sat.mod_2) # show regression coefficients table
# 
# Call:
#   lm(formula = CPC ~ query_length + query_length_greater_than_4, 
#      data = ClicksG0)
# 
# Residuals:
#   Min      1Q  Median      3Q     Max 
# -13.065  -6.333  -2.454   3.915  79.217 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)                   2.2011     0.5018   4.387 1.18e-05 ***
#   query_length                  2.7210     0.1886  14.425  < 2e-16 ***
#   query_length_greater_than_4  -7.3820     1.0198  -7.239 5.44e-13 ***
#   ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 8.842 on 3817 degrees of freedom
# Multiple R-squared:  0.05172,	Adjusted R-squared:  0.05122 
# F-statistic: 104.1 on 2 and 3817 DF,  p-value: < 2.2e-16



ClicksG0$CTR_Normal <- transformTukey(ClicksG0$CTR, start = -10, end = 10, int = 0.025, plotit = TRUE,verbose = FALSE, statistic = 1)

# lambda      W Shapiro.p.value
# 396 -0.125 0.9894       2.662e-16
# 
# if (lambda >  0){TRANS = x ^ lambda} 
# if (lambda == 0){TRANS = log(x)} 
# if (lambda <  0){TRANS = -1 * x ^ lambda} 

write.csv(ClicksG0, "CTRNormal.csv")



new = ClicksG0 %>% group_by(query_length) %>% summarise(avgCTR = mean(CTR, na.rm=T), count = n(), total=sum(CTR, na.rm=T))
new
new_1 = ClicksG0 %>% group_by(query_length) %>% summarise(avgCTR = mean(CTR, na.rm=T))# count = n())
new_1
plot(new_1)


df1 = ClicksG0 %>%
  group_by(query_length) %>%
  filter(!(abs(CTR - median(CTR)) > 2*sd(CTR))) %>%
  summarise(avgCTR = mean(CTR, na.rm=T))# count = n(), total=sum(CTR, na.rm=T))

df2 = ClicksG0 %>%
  group_by(query_length) %>%
  filter(!(abs(CTR - median(CTR)) > 2*sd(CTR))) %>%
  summarise(avgCPC = mean(CTR, na.rm=T))#count = n(), total=sum(CPC, na.rm=T)

plot(df1)


sat.mod <- lm(CTR ~ query_length, # regression formula
              data=ClicksG0) # data set
# Summarize and print the results
summary(sat.mod) # show regression coefficients table
# 
# Call:
#   lm(formula = CTR ~ query_length, data = ClicksG0)
# 
# Residuals:
#   Min       1Q   Median       3Q      Max 
# -0.13703 -0.09258 -0.06984 -0.01098  0.92323 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)   0.154228   0.009519  16.202  < 2e-16 ***
#   query_length -0.015492   0.003436  -4.509 6.71e-06 ***
#   ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 0.1886 on 3818 degrees of freedom
# Multiple R-squared:  0.005297,	Adjusted R-squared:  0.005036 
# F-statistic: 20.33 on 1 and 3818 DF,  p-value: 6.707e-06


sat.mod_2 <- lm(CTR ~ query_length + query_length_greater_than_4, # regression formula
                data=ClicksG0) # data set
# Summarize and print the results
summary(sat.mod_2) # show regression coefficients table
# Call:
#   lm(formula = CTR ~ query_length + query_length_greater_than_4, 
#      data = ClicksG0)
# 
# Residuals:
#   Min       1Q   Median       3Q      Max 
# -0.14662 -0.09226 -0.06758 -0.01024  0.91968 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)                  0.170987   0.010686  16.001  < 2e-16 ***
#   query_length                -0.022666   0.004017  -5.642  1.8e-08 ***
#   query_length_greater_than_4  0.074556   0.021718   3.433 0.000603 ***
#   ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 0.1883 on 3817 degrees of freedom
# Multiple R-squared:  0.008359,	Adjusted R-squared:  0.007839 
# F-statistic: 16.09 on 2 and 3817 DF,  p-value: 1.103e-07

regdf <- lm(RPC~Impressions+CTR+CPC+factor(Search.Engine)+factor(Listing.Match.Type)+Avg.Position + Conversions, data=ClicksG0)
summary(regdf)
# 
# lm(formula = RPC ~ Impressions + CTR + CPC + factor(Search.Engine) + 
#      factor(Listing.Match.Type) + Avg.Position + Conversions, 
#    data = ClicksG0)
# 
# Residuals:
#   Min      1Q  Median      3Q     Max 
# -11.784  -2.506  -0.867   0.361  97.990 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)                              7.984e-01  3.218e-01   2.481  0.01314 *  
#   Impressions                             -2.432e-06  3.589e-06  -0.678  0.49803    
# CTR                                      1.432e+00  6.216e-01   2.303  0.02133 *  
#   CPC                                      1.086e-01  1.400e-02   7.758 1.10e-14 ***
#   factor(Search.Engine)Microsoft Bing Ads -2.036e+00  2.694e-01  -7.555 5.21e-14 ***
#   factor(Search.Engine)Yahoo Gemini        5.906e-01  6.903e-01   0.856  0.39232    
# factor(Listing.Match.Type)Content       -1.249e+00  3.787e+00  -0.330  0.74156    
# factor(Listing.Match.Type)Exact          7.766e-01  2.512e-01   3.091  0.00201 ** 
#   factor(Listing.Match.Type)Phrase         5.748e-02  2.865e-01   0.201  0.84104    
# Avg.Position                             3.028e-01  1.420e-01   2.133  0.03300 *  
#   Conversions                              4.131e-04  8.779e-04   0.471  0.63796    
# ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 6.544 on 3809 degrees of freedom
# Multiple R-squared:  0.06305,	Adjusted R-squared:  0.06059 
# F-statistic: 25.63 on 10 and 3809 DF,  p-value: < 2.2e-16

regdf_2 <- lm(CPC~Impressions+CTR+ RPC+factor(Search.Engine)+factor(Listing.Match.Type)+ Avg.Position + Conversions , data=ClicksG0)
summary(regdf_2)
# 
# Call:
#   lm(formula = CPC ~ Impressions + CTR + RPC + factor(Search.Engine) + 
#        factor(Listing.Match.Type) + Avg.Position + Conversions, 
#      data = ClicksG0)
# 
# Residuals:
#   Min      1Q  Median      3Q     Max 
# -28.147  -4.655  -0.968   2.713  72.615 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)                              8.648e+00  3.424e-01  25.259  < 2e-16 ***
#   Impressions                             -7.915e-06  4.121e-06  -1.921   0.0548 .  
# CTR                                     -1.203e+01  6.874e-01 -17.493  < 2e-16 ***
#   RPC                                      1.433e-01  1.847e-02   7.758  1.1e-14 ***
#   factor(Search.Engine)Microsoft Bing Ads -8.440e+00  2.802e-01 -30.117  < 2e-16 ***
#   factor(Search.Engine)Yahoo Gemini       -8.948e+00  7.797e-01 -11.476  < 2e-16 ***
#   factor(Listing.Match.Type)Content       -9.078e+00  4.347e+00  -2.088   0.0368 *  
#   factor(Listing.Match.Type)Exact          4.261e-01  2.888e-01   1.475   0.1403    
# factor(Listing.Match.Type)Phrase        -4.144e-01  3.291e-01  -1.259   0.2080    
# Avg.Position                             2.502e+00  1.581e-01  15.826  < 2e-16 ***
#   Conversions                             -6.064e-04  1.008e-03  -0.601   0.5477    
# ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 7.517 on 3809 degrees of freedom
# Multiple R-squared:  0.316,	Adjusted R-squared:  0.3142 
# F-statistic:   176 on 10 and 3809 DF,  p-value: < 2.2e-16

ClicksG0_1 <- read.csv("RPC_binomial.csv")

mylogit <- glm(RPC_binomial~Impressions+CTR+CPC+factor(Search.Engine)+factor(Listing.Match.Type)+Avg.Position + Conversions, data=ClicksG0_1, family = "binomial")

# Call:
#   glm(formula = RPC_binomial ~ Impressions + CTR + CPC + factor(Search.Engine) + 
#         factor(Listing.Match.Type) + Avg.Position + Conversions, 
#       family = "binomial", data = ClicksG0_1)
# 
# Deviance Residuals: 
#   Min          1Q      Median          3Q         Max  
# -7.897e-05  -5.918e-05  -2.262e-05   2.000e-08   3.678e-04  
# 
# Coefficients:
#   Estimate Std. Error z value Pr(>|z|)
# (Intercept)                             -2.015e+01  7.647e+02  -0.026    0.979
# Impressions                             -1.238e-05  6.523e-02   0.000    1.000
# CTR                                     -5.069e-01  1.467e+03   0.000    1.000
# CPC                                      6.093e-03  2.773e+01   0.000    1.000
# factor(Search.Engine)Microsoft Bing Ads -1.909e+00  9.907e+02  -0.002    0.998
# factor(Search.Engine)Yahoo Gemini        1.880e-01  1.349e+03   0.000    1.000
# factor(Listing.Match.Type)Content       -6.081e+00  2.012e+05   0.000    1.000
# factor(Listing.Match.Type)Exact          1.074e-01  5.785e+02   0.000    1.000
# factor(Listing.Match.Type)Phrase        -5.169e-03  6.661e+02   0.000    1.000
# Avg.Position                            -1.879e-02  3.108e+02   0.000    1.000
# Conversions                              3.885e+01  4.957e+02   0.078    0.938
# 
# (Dispersion parameter for binomial family taken to be 1)
# 
# Null deviance: 4.7533e+03  on 3819  degrees of freedom
# Residual deviance: 1.2136e-05  on 3809  degrees of freedom
# AIC: 22
# 
# Number of Fisher Scoring iterations: 25


new_interaction_2 = ClicksG0 %>% group_by(ClicksG0$Search.Engine) %>% summarise(avgRPC = mean(RPC, na.rm=T), count = n(),  sd = sd(RPC, na.rm = TRUE), total = sum(RPC, na.rm=T))
colnames(new_interaction_2)[1] <- "Search.Engine"

# Search.Engine      avgRPC count    sd  total
# <fct>               <dbl> <int> <dbl>  <dbl>
#   1 Google Adwords     3.02    2625  7.79 7920. 
# 2 Microsoft Bing Ads 0.0574  1096  1.53   62.9
# 3 Yahoo Gemini       2.31      99  7.65  229. 

ggplot(data=new_interaction_2, aes(x=Search.Engine, y=avgRPC)) +
  geom_bar(stat="identity", fill="steelblue")+
  geom_text(aes(label=avgRPC), vjust=-0.1, color="black", size=3.5)+
  theme_minimal()

# # A tibble: 3 x 5
# Search.Engine      avgRPC count    sd  total
# <fct>               <dbl> <int> <dbl>  <dbl>
#   1 Google Adwords     3.02    2625  7.79 7920. 
# 2 Microsoft Bing Ads 0.0574  1096  1.53   62.9
# 3 Yahoo Gemini       2.31      99  7.65  229. 

new_interaction_4 = ClicksG0 %>% group_by(ClicksG0$Listing.Match.Type) %>% summarise(avgCPC = mean(CPC, na.rm=T), count = n(),  sd = sd(CPC, na.rm = TRUE), total = sum(CPC, na.rm=T))
colnames(new_interaction_4)[1] <- "Listing.Match.Type"

# Listing.Match.Type avgCPC count     sd    total
# <fct>               <dbl> <int>  <dbl>    <dbl>
#   1 Broad                8.98  1780  8.54  15977.  
# 2 Content              1.79     3  0.200     5.37
# 3 Exact                9.77  1262 10.3   12332.  
# 4 Phrase               8.50   775  8.15   6590. 

ggplot(data=new_interaction_4, aes(x=Listing.Match.Type, y=avgCPC)) +
  geom_bar(stat="identity", fill="steelblue")+
  geom_text(aes(label=avgCPC), vjust=-0.1, color="black", size=3.5)+
  theme_minimal()


new_interaction_3 = ClicksG0 %>% group_by(ClicksG0$Search.Engine) %>% summarise(avgCPC = mean(CPC, na.rm=T), count = n(),  sd = sd(CPC, na.rm = TRUE), total = sum(CPC, na.rm=T))
colnames(new_interaction_3)[1] <- "Search.Engine"

ggplot(data=new_interaction_3, aes(x=Search.Engine, y=avgCPC)) +
  geom_bar(stat="identity", fill="steelblue")+
  geom_text(aes(label=avgCPC), vjust=-0.1, color="black", size=3.5)+
  theme_minimal()
# Search.Engine      avgCPC count    sd  total
# <fct>               <dbl> <int> <dbl>  <dbl>
#   1 Google Adwords      11.6   2625  9.85 30451.
# 2 Microsoft Bing Ads   3.83  1096  2.72  4193.
# 3 Yahoo Gemini         2.63    99  2.91   260.


new_interaction_5 = ClicksG0 %>% group_by(ClicksG0$Listing.Match.Type) %>% summarise(avgCTR = mean(CTR, na.rm=T), count = n(),  sd = sd(CTR, na.rm = TRUE), total = sum(CTR, na.rm=T))
colnames(new_interaction_5)[1] <- "Listing.Match.Type"

# Listing.Match.Type  avgCTR count      sd    total
# <fct>                <dbl> <int>   <dbl>    <dbl>
#   1 Broad              0.0670   1780 0.132   119.    
# 2 Content            0.00780     3 0.00910   0.0234
# 3 Exact              0.163    1262 0.218   205.    
# 4 Phrase             0.141     775 0.223   109.   

ggplot(data=new_interaction_5, aes(x=Listing.Match.Type, y=avgCTR)) +
  geom_bar(stat="identity", fill="steelblue")+
  geom_text(aes(label=avgCTR), vjust=-0.1, color="black", size=3.5)+
  theme_minimal()

new_interaction_5

new_interaction_6 = ClicksG0 %>% group_by(ClicksG0$Listing.Match.Type) %>% summarise(avgRPC = mean(RPC, na.rm=T), count = n(),  sd = sd(RPC, na.rm = TRUE), total = sum(RPC, na.rm=T))
colnames(new_interaction_6)[1] <- "Listing.Match.Type"

ggplot(data=new_interaction_6, aes(x=Listing.Match.Type, y=avgRPC)) +
  geom_bar(stat="identity", fill="steelblue")+
  geom_text(aes(label=avgRPC), vjust=-0.1, color="black", size=3.5)+
  theme_minimal()

new_interaction_6
# 
# Listing.Match.Type avgRPC count    sd total
# <fct>               <dbl> <int> <dbl> <dbl>
#   1 Broad                1.69  1780  5.82 3011.
# 2 Content              0        3  0       0 
# 3 Exact                2.92  1262  7.64 3690.
# 4 Phrase               1.95   775  7.11 1511.

new_interaction_7 = ClicksG0 %>% group_by(ClicksG0$Search.Engine) %>% summarise(avgCTR = mean(CTR, na.rm=T), count = n(),  sd = sd(CTR, na.rm = TRUE), total = sum(CTR, na.rm=T))
colnames(new_interaction_7)[1] <- "Search.Engine"

# Listing.Match.Type  avgCTR count      sd    total
# <fct>                <dbl> <int>   <dbl>    <dbl>
#   1 Broad              0.0670   1780 0.132   119.    
# 2 Content            0.00780     3 0.00910   0.0234
# 3 Exact              0.163    1262 0.218   205.    
# 4 Phrase             0.141     775 0.223   109.   

ggplot(data=new_interaction_7, aes(x=Search.Engine, y=avgCTR)) +
  geom_bar(stat="identity", fill="steelblue")+
  geom_text(aes(label=avgCTR), vjust=-0.1, color="black", size=3.5)+
  theme_minimal()

new_interaction_7

# Search.Engine      avgCTR count    sd  total
# <fct>               <dbl> <int> <dbl>  <dbl>
#   1 Google Adwords     0.129   2625 0.198 339.  
# 2 Microsoft Bing Ads 0.0799  1096 0.160  87.5 
# 3 Yahoo Gemini       0.0739    99 0.182   7.31

# new_interaction_8 = ClicksG0 %>% group_by(ClicksG0$Search.Engine) %>% summarise(avgRPC = mean(RPC, na.rm=T), countRPC = n(),  sdRPC = sd(RPC, na.rm = TRUE), totalRPC = sum(RPC, na.rm=T),
#                                                                                 avgCPC = mean(CPC, na.rm=T), countCPC = n(),  sdCPC = sd(CPC, na.rm = TRUE), totalCPC = sum(CPC, na.rm=T),
#                                                                                 avgImpressions = mean(Impressions, na.rm=T), countImpressions = n(),  sdImpressions = sd(Impressions, na.rm = TRUE), totalImpressions = sum(Impressions, na.rm=T),
#                                                                                 avgConversions = mean(Conversions, na.rm=T), countConversions = n(),  sdConversions = sd(Conversions, na.rm = TRUE), totalConversions = sum(Conversions, na.rm=T),
#                                                                                 avgClicks = mean(Clicks, na.rm=T), countClicks = n(),  sdClicks = sd(Clicks, na.rm = TRUE), totalClicks = sum(Clicks, na.rm=T),
#                                                                                 avgCost = mean(Cost, na.rm=T), countCost = n(),  sdCost = sd(Cost, na.rm = TRUE), totalCost = sum(Cost, na.rm=T))


df_Search <- lm (RPC~ factor(Search.Engine), data=ClicksG0)
# Call:
#   lm(formula = RPC ~ factor(Search.Engine), data = ClicksG0)
# 
# Residuals:
#   Min     1Q Median     3Q    Max 
# -3.017 -3.017 -0.795 -0.057 96.983 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)                               3.0171     0.1292  23.347   <2e-16 ***
#   factor(Search.Engine)Microsoft Bing Ads  -2.9598     0.2381 -12.430   <2e-16 ***
#   factor(Search.Engine)Yahoo Gemini        -0.7036     0.6779  -1.038    0.299    
# ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 6.621 on 3817 degrees of freedom
# Multiple R-squared:  0.03892,	Adjusted R-squared:  0.03841 
# F-statistic: 77.28 on 2 and 3817 DF,  p-value: < 2.2e-16

df_Search_CPC <- lm (CPC~ factor(Search.Engine), data=ClicksG0)
# Call:
#   lm(formula = CPC ~ factor(Search.Engine), data = ClicksG0)
# 
# Residuals:
#   Min      1Q  Median      3Q     Max 
# -11.590  -4.850  -1.010   3.016  75.260 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)                              11.6004     0.1622   71.52   <2e-16 ***
#   factor(Search.Engine)Microsoft Bing Ads  -7.7749     0.2989  -26.01   <2e-16 ***
#   factor(Search.Engine)Yahoo Gemini        -8.9722     0.8508  -10.54   <2e-16 ***
#   ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 8.31 on 3817 degrees of freedom
# Multiple R-squared:  0.1622,	Adjusted R-squared:  0.1618 
# F-statistic: 369.5 on 2 and 3817 DF,  p-value: < 2.2e-16

df_Search_CTR <- lm (CTR~ factor(Search.Engine), data=ClicksG0)
# Call:
#   lm(formula = CTR ~ factor(Search.Engine), data = ClicksG0)
# 
# Residuals:
#   Min       1Q   Median       3Q      Max 
# -0.12743 -0.09551 -0.06464 -0.00845  0.92614 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)                              0.129137   0.003663  35.255  < 2e-16 ***
#   factor(Search.Engine)Microsoft Bing Ads -0.049259   0.006749  -7.298 3.53e-13 ***
#   factor(Search.Engine)Yahoo Gemini       -0.055280   0.019214  -2.877  0.00404 ** 
#   ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 0.1877 on 3817 degrees of freedom
# Multiple R-squared:  0.01492,	Adjusted R-squared:  0.01441 
# F-statistic: 28.91 on 2 and 3817 DF,  p-value: 3.462e-13                               -0.04926                                 -0.05528 

summary(lm (CTR~ factor(Listing.Match.Type), data=ClicksG0))
# Call:
#   lm(formula = CTR ~ factor(Listing.Match.Type), data = ClicksG0)
# 
# Residuals:
#   Min       1Q   Median       3Q      Max 
# -0.16116 -0.09609 -0.04917 -0.01085  0.93298 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)                        0.067017   0.004357  15.381   <2e-16 ***
#   factor(Listing.Match.Type)Content -0.059220   0.106223  -0.558    0.577    
# factor(Listing.Match.Type)Exact    0.095737   0.006765  14.152   <2e-16 ***
#   factor(Listing.Match.Type)Phrase   0.073798   0.007911   9.328   <2e-16 ***
#   ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 0.1838 on 3816 degrees of freedom
# Multiple R-squared:  0.0551,	Adjusted R-squared:  0.05435 
# F-statistic: 74.17 on 3 and 3816 DF,  p-value: < 2.2e-16



summary(lm (RPC~ factor(Listing.Match.Type), data=ClicksG0))

# Call:
#   lm(formula = RPC ~ factor(Listing.Match.Type), data = ClicksG0)
# 
# Residuals:
#   Min     1Q Median     3Q    Max 
# -2.924 -1.950 -1.692 -0.484 98.308 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)                         1.6915     0.1596  10.601  < 2e-16 ***
#   factor(Listing.Match.Type)Content  -1.6915     3.8899  -0.435    0.664    
# factor(Listing.Match.Type)Exact     1.2324     0.2477   4.975 6.82e-07 ***
#   factor(Listing.Match.Type)Phrase    0.2583     0.2897   0.891    0.373    
# ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 6.732 on 3816 degrees of freedom
# Multiple R-squared:  0.006748,	Adjusted R-squared:  0.005967 
# F-statistic: 8.642 on 3 and 3816 DF,  p-value: 1.029e-05


df_LMT <- lm (CPC~ factor(Listing.Match.Type), data=ClicksG0)
# Call:
#   lm(formula = CPC ~ factor(Listing.Match.Type), data = ClicksG0)
# 
# Residuals:
#   Min     1Q Median     3Q    Max 
# -9.761 -6.557 -2.964  4.210 77.089 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)                         8.9759     0.2149  41.772   <2e-16 ***
#   factor(Listing.Match.Type)Content  -7.1859     5.2385  -1.372   0.1702    
# factor(Listing.Match.Type)Exact     0.7955     0.3336   2.385   0.0171 *  
#   factor(Listing.Match.Type)Phrase   -0.4730     0.3902  -1.212   0.2255    
# ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 9.066 on 3816 degrees of freedom
# Multiple R-squared:  0.003266,	Adjusted R-squared:  0.002482 
# F-statistic: 4.168 on 3 and 3816 DF,  p-value: 0.005894


summary (ClicksG0)

ClicksG0_Google <- ClicksG0[which(ClicksG0$Search.Engine =='Google Adwords'),]
ClicksG0_Microsoft<- ClicksG0[which(ClicksG0$Search.Engine =='Microsoft Bing Ads'),]
ClicksG0_Yahoo <- ClicksG0[which(ClicksG0$Search.Engine =='Yahoo Gemini'),]

new = ClicksG0_Google %>% group_by(query_length) %>% summarise(avgCPC = mean(CPC, na.rm=T), count = n(), total=sum(CPC, na.rm=T))
new
new_1 = ClicksG0_Google %>% group_by(query_length) %>% summarise(avgCPC = mean(CPC, na.rm=T))# count = n())
new_1
plot(new_1)


sat.mod <- lm(CPC ~ query_length, # regression formula
              data=ClicksG0_Google) # data set
# Summarize and print the results
summary(sat.mod) # show regression coefficients table

# Call:
#   lm(formula = CPC ~ query_length, data = ClicksG0_Google)
# 
# Residuals:
#   Min      1Q  Median      3Q     Max 
# -20.616  -6.758  -1.708   4.511  77.251 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)    2.8311     0.5836   4.851  1.3e-06 ***
#   query_length   3.3892     0.2141  15.832  < 2e-16 ***
#   ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 9.414 on 2623 degrees of freedom
# Multiple R-squared:  0.08723,	Adjusted R-squared:  0.08688 
# F-statistic: 250.7 on 1 and 2623 DF,  p-value: < 2.2e-16


sat.mod_2 <- lm(CPC ~ query_length + query_length_greater_than_4, # regression formula
                data=ClicksG0_Google) # data set
# Summarize and print the results
summary(sat.mod_2) # show regression coefficients table
# Call:
#   lm(formula = CPC ~ query_length + query_length_greater_than_4, 
#      data = ClicksG0_Google)
# 
# Residuals:
#   Min      1Q  Median      3Q     Max 
# -17.815  -6.721  -1.527   4.193  77.513 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)                   0.8589     0.6382   1.346    0.179    
# query_length                  4.2439     0.2423  17.513  < 2e-16 ***
#   query_length_greater_than_4  -9.8172     1.3487  -7.279 4.43e-13 ***
#   ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 9.323 on 2622 degrees of freedom
# Multiple R-squared:  0.1053,	Adjusted R-squared:  0.1046 
# F-statistic: 154.3 on 2 and 2622 DF,  p-value: < 2.2e-16


new = ClicksG0_Yahoo %>% group_by(query_length) %>% summarise(avgCPC = mean(CPC, na.rm=T), count = n(), total=sum(CPC, na.rm=T))
new
new_1 = ClicksG0_Yahoo %>% group_by(query_length) %>% summarise(avgCPC = mean(CPC, na.rm=T))# count = n())
new_1
plot(new_1)


sat.mod <- lm(CPC ~ query_length, # regression formula
              data=ClicksG0_Yahoo) # data set
# Summarize and print the results
summary(sat.mod) # show regression coefficients table


# Call:
#   lm(formula = CPC ~ query_length, data = ClicksG0_Yahoo)
# 
# Residuals:
#   Min      1Q  Median      3Q     Max 
# -3.9556 -1.6995 -0.5295  0.7575 11.2205 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)   -1.1727     0.9560  -1.227    0.223    
# query_length   1.7261     0.4163   4.146 7.24e-05 ***
#   ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 2.697 on 97 degrees of freedom
# Multiple R-squared:  0.1505,	Adjusted R-squared:  0.1418 
# F-statistic: 17.19 on 1 and 97 DF,  p-value: 7.243e-05
# # 
# 
# 


ClicksG0_Exact <- ClicksG0[which(ClicksG0$Listing.Match.Type =='Exact'),]
ClicksG0_Broad<- ClicksG0[which(ClicksG0$Listing.Match.Type =='Broad'),]
ClicksG0_Phrase <- ClicksG0[which(ClicksG0$SListing.Match.Type =='Phrase'),]

new = ClicksG0_Exact %>% group_by(query_length) %>% summarise(avgCPC = mean(CPC, na.rm=T), count = n(), total=sum(CPC, na.rm=T))
new
new_1 = ClicksG0_Exact %>% group_by(query_length) %>% summarise(avgCPC = mean(CPC, na.rm=T))# count = n())
new_1
plot(new_1)

new = ClicksG0_Broad %>% group_by(query_length) %>% summarise(avgCPC = mean(CPC, na.rm=T), count = n(), total=sum(CPC, na.rm=T))
new
new_1 = ClicksG0_Broad %>% group_by(query_length) %>% summarise(avgCPC = mean(CPC, na.rm=T))# count = n())
new_1
plot(new_1)

new = ClicksG0_Phrase %>% group_by(query_length) %>% summarise(avgCPC = mean(CPC, na.rm=T), count = n(), total=sum(CPC, na.rm=T))
new
new_1 = ClicksG0_Phrase %>% group_by(query_length) %>% summarise(avgCPC = mean(CPC, na.rm=T))# count = n())
new_1
plot(new_1)


sat.mod <- lm(CPC ~ query_length, # regression formula
              data=ClicksG0_Exact) # data set
# Summarize and print the results
summary(sat.mod) # show regression coefficients table

# Call:
#   lm(formula = CPC ~ query_length, data = ClicksG0_Exact)
# 
# Residuals:
#   Min      1Q  Median      3Q     Max 
# -14.049  -6.998  -2.930   3.891  78.365 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)    4.7656     0.9051   5.265 1.64e-07 ***
#   query_length   1.8646     0.3200   5.827 7.15e-09 ***
#   ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 10.12 on 1260 degrees of freedom
# Multiple R-squared:  0.02624,	Adjusted R-squared:  0.02547 
# F-statistic: 33.95 on 1 and 1260 DF,  p-value: 7.155e-09



sat.mod_2 <- lm(CPC ~ query_length + query_length_greater_than_4, # regression formula
                data=ClicksG0_Exact) # data set
# Summarize and print the results
summary(sat.mod_2)


# Call:
#   lm(formula = CPC ~ query_length + query_length_greater_than_4, 
#      data = ClicksG0_Exact)
# 
# Residuals:
#   Min      1Q  Median      3Q     Max 
# -13.443  -7.048  -2.853   4.157  78.650 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)                   2.9580     1.0380   2.850 0.004448 ** 
#   query_length                  2.6262     0.3855   6.812 1.49e-11 ***
#   query_length_greater_than_4  -6.3586     1.8127  -3.508 0.000468 ***
#   ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 10.08 on 1259 degrees of freedom
# Multiple R-squared:  0.03567,	Adjusted R-squared:  0.03413 
# F-statistic: 23.28 on 2 and 1259 DF,  p-value: 1.178e-10

sat.mod <- lm(CPC ~ query_length, # regression formula
              data=ClicksG0_Broad) # data set
# Summarize and print the results
summary(sat.mod) # show regression coefficients table

# Call:
#   lm(formula = CPC ~ query_length, data = ClicksG0_Broad)
# 
# Residuals:
#   Min      1Q  Median      3Q     Max 
# -14.127  -5.768  -2.458   3.645  53.932 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)    3.6989     0.6122   6.042 1.85e-09 ***
#   query_length   1.9896     0.2184   9.109  < 2e-16 ***
#   ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 8.346 on 1778 degrees of freedom
# Multiple R-squared:  0.04458,	Adjusted R-squared:  0.04405 
# F-statistic: 82.97 on 1 and 1778 DF,  p-value: < 2.2e-16



sat.mod_2 <- lm(CPC ~ query_length + query_length_greater_than_4, # regression formula
                data=ClicksG0_Broad) # data set
# Summarize and print the results
summary(sat.mod_2)


# Call:
#   lm(formula = CPC ~ query_length + query_length_greater_than_4, 
#      data = ClicksG0_Broad)
# 
# Residuals:
#   Min      1Q  Median      3Q     Max 
# -12.403  -5.869  -2.068   3.521  53.369 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)                   1.5542     0.6633   2.343   0.0192 *  
#   query_length                  2.8923     0.2446  11.822  < 2e-16 ***
#   query_length_greater_than_4 -11.9927     1.5529  -7.723 1.89e-14 ***
#   ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 8.211 on 1777 degrees of freedom
# Multiple R-squared:  0.07561,	Adjusted R-squared:  0.07457 
# F-statistic: 72.67 on 2 and 1777 DF,  p-value: < 2.2e-16



ClicksG0_Google_Exact <- ClicksG0_Google[which(ClicksG0_Google$Listing.Match.Type =='Exact'),]
ClicksG0_Google_Broad<- ClicksG0_Google[which(ClicksG0_Google$Listing.Match.Type =='Broad'),]
ClicksG0_Google_Phrase <- ClicksG0_Google[which(ClicksG0_Google$Listing.Match.Type =='Phrase'),]
ClicksG0_Yahoo_Broad <- ClicksG0_Yahoo[which(ClicksG0_Yahoo$Listing.Match.Type =='Broad'),]


new = ClicksG0_Google_Exact %>% group_by(query_length) %>% summarise(avgCPC = mean(CPC, na.rm=T), count = n(), total=sum(CPC, na.rm=T))
new
new_1 = ClicksG0_Google_Exact %>% group_by(query_length) %>% summarise(avgCPC = mean(CPC, na.rm=T))# count = n())
new_1
plot(new_1)


sat.mod <- lm(CPC ~ query_length, # regression formula
              data=ClicksG0_Google_Exact) # data set
# Summarize and print the results
summary(sat.mod) # show regression coefficients table

# Call:
#   lm(formula = CPC ~ query_length, data = ClicksG0_Google_Exact)
# 
# Residuals:
#   Min      1Q  Median      3Q     Max 
# -16.903  -7.850  -2.163   4.677  76.587 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)    5.6832     1.1259   5.048 5.37e-07 ***
#   query_length   2.2949     0.3968   5.784 9.93e-09 ***
#   ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 10.79 on 938 degrees of freedom
# Multiple R-squared:  0.03444,	Adjusted R-squared:  0.03341 
# F-statistic: 33.46 on 1 and 938 DF,  p-value: 9.928e-09



sat.mod_2 <- lm(CPC ~ query_length + query_length_greater_than_4, # regression formula
                data=ClicksG0_Google_Exact) # data set
# Summarize and print the results
summary(sat.mod_2)


new = ClicksG0_Google_Broad %>% group_by(query_length) %>% summarise(avgCPC = mean(CPC, na.rm=T), count = n(), total=sum(CPC, na.rm=T))
new
new_1 = ClicksG0_Google_Broad %>% group_by(query_length) %>% summarise(avgCPC = mean(CPC, na.rm=T))# count = n())
new_1
plot(new_1)


sat.mod <- lm(CPC ~ query_length, # regression formula
              data=ClicksG0_Google_Broad) # data set
# Summarize and print the results
summary(sat.mod) # show regression coefficients table

# Call:
#   lm(formula = CPC ~ query_length, data = ClicksG0_Google_Broad)
# 
# Residuals:
#   Min      1Q  Median      3Q     Max 
# -25.765  -5.492  -1.478   3.909  49.436 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)  -0.01663    0.81576   -0.02    0.984    
# query_length  4.72692    0.30375   15.56   <2e-16 ***
#   ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 8.48 on 1112 degrees of freedom
# Multiple R-squared:  0.1788,	Adjusted R-squared:  0.1781 
# F-statistic: 242.2 on 1 and 1112 DF,  p-value: < 2.2e-16



sat.mod_2 <- lm(CPC ~ query_length + query_length_greater_than_4, # regression formula
                data=ClicksG0_Google_Broad) # data set
# Summarize and print the results
summary(sat.mod_2)


# Call:
#   lm(formula = CPC ~ query_length + query_length_greater_than_4, 
#      data = ClicksG0_Google_Broad)
# 
# Residuals:
#   Min      1Q  Median      3Q     Max 
# -14.586  -5.410  -1.401   3.848  48.994 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)                  -1.4537     0.8366  -1.738   0.0826 .  
# query_length                  5.3531     0.3161  16.937  < 2e-16 ***
#   query_length_greater_than_4 -16.3100     2.6738  -6.100 1.46e-09 ***
#   ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 8.346 on 1111 degrees of freedom
# Multiple R-squared:  0.2054,	Adjusted R-squared:  0.204 
# F-statistic: 143.6 on 2 and 1111 DF,  p-value: < 2.2e-16

new = ClicksG0_Yahoo_Broad %>% group_by(query_length) %>% summarise(avgCPC = mean(CPC, na.rm=T), count = n(), total=sum(CPC, na.rm=T))
new
new_1 = ClicksG0_Yahoo_Broad %>% group_by(query_length) %>% summarise(avgCPC = mean(CPC, na.rm=T))# count = n())
new_1
plot(new_1)


sat.mod <- lm(CPC ~ query_length, # regression formula
              data=ClicksG0_Yahoo_Broad) # data set
# Summarize and print the results
summary(sat.mod) # show regression coefficients table

# Call:
#   lm(formula = CPC ~ query_length, data = ClicksG0_Yahoo_Broad)
# 
# Residuals:
#   Min      1Q  Median      3Q     Max 
# -4.3871 -1.7605 -0.6905  1.0861 11.0795 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)   -2.0928     1.1947  -1.752   0.0844 .  
# query_length   2.2566     0.5145   4.386 4.18e-05 ***
#   ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 2.737 on 67 degrees of freedom
# Multiple R-squared:  0.2231,	Adjusted R-squared:  0.2115 
# F-statistic: 19.23 on 1 and 67 DF,  p-value: 4.183e-05


df_Google_reg <- lm(CPC~Impressions+Avg.Position+Conversions+Clicks, data=ClicksG0_Google_Broad)

# Call:
#   lm(formula = CPC ~ Impressions + Avg.Position + Conversions + 
#        Clicks, data = ClicksG0_Google_Broad)
# 
# Residuals:
#   Min      1Q  Median      3Q     Max 
# -28.343  -6.157  -1.449   4.234  51.388 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)   2.840e+00  7.017e-01   4.048 5.53e-05 ***
#   Impressions  -4.370e-06  1.004e-05  -0.435  0.66341    
# Avg.Position  5.844e+00  4.119e-01  14.188  < 2e-16 ***
#   Conversions   4.083e-02  1.421e-02   2.874  0.00413 ** 
#   Clicks       -1.063e-03  3.481e-04  -3.053  0.00232 ** 
#   ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 8.58 on 1109 degrees of freedom
# Multiple R-squared:  0.1616,	Adjusted R-squared:  0.1586 
# F-statistic: 53.46 on 4 and 1109 DF,  p-value: < 2.2e-16


summary(lm(formula = CPC ~ Impressions + Avg.Position + Conversions + 
             +                Clicks, data = ClicksG0_Google_Exact))

# Call:
#   lm(formula = CPC ~ Impressions + Avg.Position + Conversions + 
#        Clicks, data = ClicksG0_Google_Exact)
# 
# Residuals:
#   Min      1Q  Median      3Q     Max 
# -25.824  -6.831  -1.926   4.231  72.562 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)   4.264e+00  7.109e-01   5.998 2.85e-09 ***
#   Impressions   7.474e-05  1.107e-04   0.675    0.500    
# Avg.Position  4.324e+00  3.558e-01  12.154  < 2e-16 ***
#   Conversions  -5.797e-04  3.037e-03  -0.191    0.849    
# Clicks       -2.378e-04  2.461e-04  -0.966    0.334    
# ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 10.2 on 935 degrees of freedom
# Multiple R-squared:  0.1398,	Adjusted R-squared:  0.1361 
# F-statistic: 37.98 on 4 and 935 DF,  p-value: < 2.2e-16



summary(lm(formula = CPC ~ Impressions + Avg.Position + Conversions + 
             +                Clicks, data = ClicksG0_Yahoo_Broad))

# Call:
#   lm(formula = CPC ~ Impressions + Avg.Position + Conversions + 
#        +Clicks, data = ClicksG0_Yahoo_Broad)
# 
# Residuals:
#   Min      1Q  Median      3Q     Max 
# -3.4297 -1.9164 -0.7447  0.7092  9.7898 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)   5.119e+00  9.296e-01   5.506 6.94e-07 ***
#   Impressions  -4.962e-06  7.131e-06  -0.696   0.4890    
# Avg.Position -1.368e+00  5.309e-01  -2.577   0.0123 *  
#   Conversions  -5.713e-03  2.478e-02  -0.231   0.8184    
# Clicks        7.788e-04  2.152e-03   0.362   0.7186    
# ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 3.01 on 64 degrees of freedom
# Multiple R-squared:  0.1023,	Adjusted R-squared:  0.04616 
# F-statistic: 1.823 on 4 and 64 DF,  p-value: 0.1353
summary(ClicksG0_Google_Exact)

summary(ClicksG0_Yahoo_Broad)



new = ClicksG0_Google %>% group_by(query_length) %>% summarise(avgRPC = mean(RPC, na.rm=T), count = n(), total=sum(RPC, na.rm=T))
new
new_1 = ClicksG0_Google %>% group_by(query_length) %>% summarise(avgRPC = mean(RPC, na.rm=T))# count = n())
new_1
plot(new_1)


new = ClicksG0_Microsoft %>% group_by(query_length) %>% summarise(avgRPC = mean(RPC, na.rm=T), count = n(), total=sum(RPC, na.rm=T))
new
new_1 = ClicksG0_Microsoft %>% group_by(query_length) %>% summarise(avgRPC = mean(RPC, na.rm=T))# count = n())
new_1
plot(new_1)


new = ClicksG0_Broad %>% group_by(query_length) %>% summarise(avgRPC = mean(RPC, na.rm=T), count = n(), total=sum(RPC, na.rm=T))
new
new_1 = ClicksG0_Broad %>% group_by(query_length) %>% summarise(avgRPC = mean(RPC, na.rm=T))# count = n())
new_1
plot(new_1)

new = ClicksG0_Exact %>% group_by(query_length) %>% summarise(avgRPC = mean(RPC, na.rm=T), count = n(), total=sum(RPC, na.rm=T))
new
new_1 = ClicksG0_Exact %>% group_by(query_length) %>% summarise(avgRPC = mean(RPC, na.rm=T))# count = n())
new_1
plot(new_1)


new = ClicksG0_Google_Exact %>% group_by(query_length) %>% summarise(avgRPC = mean(RPC, na.rm=T), count = n(), total=sum(RPC, na.rm=T))
new
new_1 = ClicksG0_Google_Exact %>% group_by(query_length) %>% summarise(avgRPC = mean(RPC, na.rm=T))# count = n())
new_1
plot(new_1)

ClicksG0_Microsoft_Exact  <- ClicksG0_Microsoft[which(ClicksG0_Microsoft$Listing.Match.Type =='Exact'),]
new = ClicksG0_Microsoft_Exact %>% group_by(query_length) %>% summarise(avgRPC = mean(RPC, na.rm=T), count = n(), total=sum(RPC, na.rm=T))
new
new_1 = ClicksG0_Microsoft_Exact %>% group_by(query_length) %>% summarise(avgRPC = mean(RPC, na.rm=T))# count = n())
new_1
plot(new_1)



sat.mod <- lm(RPC ~ query_length, # regression formula
              data=ClicksG0_Google_Exact) # data set
# Summarize and print the results
summary(sat.mod) # show regression coefficients table


# Call:
#   lm(formula = RPC ~ query_length, data = ClicksG0_Google_Exact)
# 
# Residuals:
#   Min     1Q Median     3Q    Max 
# -6.717 -4.122 -3.256  0.695 47.609 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)   
# (Intercept)    1.5256     0.8837   1.726  0.08461 . 
# query_length   0.8653     0.3114   2.779  0.00556 **
#   ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 8.465 on 938 degrees of freedom
# Multiple R-squared:  0.008165,	Adjusted R-squared:  0.007108 
# F-statistic: 7.722 on 1 and 938 DF,  p-value: 0.005563


sat.mod <- lm(RPC ~ query_length +query_length_greater_than_4, # regression formula
              data=ClicksG0_Google_Exact) # data set
# Summarize and print the results
summary(sat.mod) # show regression coefficients table


# Call:
#   lm(formula = RPC ~ query_length + query_length_greater_than_4, 
#      data = ClicksG0_Google_Exact)
# 
# Residuals:
#   Min     1Q Median     3Q    Max 
# -5.625 -4.365 -3.105  0.770 48.155 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)                   0.5853     1.0073   0.581 0.561309    
# query_length                  1.2599     0.3718   3.388 0.000732 ***
#   query_length_greater_than_4  -3.4169     1.7658  -1.935 0.053280 .  
# ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 8.453 on 937 degrees of freedom
# Multiple R-squared:  0.01211,	Adjusted R-squared:   0.01 
# F-statistic: 5.745 on 2 and 937 DF,  p-value: 0.003313


summary(lm(formula = RPC ~ query_length + query_length_greater_than_4, 
   data = ClicksG0_Microsoft_Exact))


# Call:
#   lm(formula = RPC ~ query_length + query_length_greater_than_4, 
#      data = ClicksG0_Microsoft_Exact)
# 
# Residuals:
#   Min      1Q  Median      3Q     Max 
# -0.1812 -0.0860  0.0093  0.0093  5.3743 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)                  0.27651    0.08212   3.367 0.000859 ***
#   query_length                -0.09527    0.03083  -3.090 0.002187 ** 
#   query_length_greater_than_4  0.22916    0.13762   1.665 0.096935 .  
# ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 0.3828 on 300 degrees of freedom
# Multiple R-squared:  0.03113,	Adjusted R-squared:  0.02467 
# F-statistic:  4.82 on 2 and 300 DF,  p-value: 0.008706

summary(lm(formula = RPC ~ query_length, 
           data = ClicksG0_Microsoft_Exact))


# Call:
#   lm(formula = RPC ~ query_length, data = ClicksG0_Microsoft_Exact)
# 
# Residuals:
#   Min      1Q  Median      3Q     Max 
# -0.1380 -0.0743 -0.0106 -0.0106  5.4175 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)   
# (Intercept)   0.20173    0.06896   2.925  0.00370 **
#   query_length -0.06370    0.02438  -2.613  0.00943 **
#   ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 0.3839 on 301 degrees of freedom
# Multiple R-squared:  0.02218,	Adjusted R-squared:  0.01893 
# F-statistic: 6.826 on 1 and 301 DF,  p-value: 0.009433

summary(lm(formula = RPC ~ query_length, 
          data = ClicksG0_Exact))
# Call:
#   lm(formula = RPC ~ query_length, data = ClicksG0_Exact)
# 
# Residuals:
#   Min     1Q Median     3Q    Max 
# -5.009 -3.122 -2.493 -0.410 48.136 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)   
# (Intercept)    1.2355     0.6812   1.814  0.06996 . 
# query_length   0.6289     0.2408   2.611  0.00913 **
#   ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 7.618 on 1260 degrees of freedom
# Multiple R-squared:  0.005382,	Adjusted R-squared:  0.004593 
# F-statistic: 6.818 on 1 and 1260 DF,  p-value: 0.00913
# 
# 
# 
summary(lm(formula = RPC ~ query_length +query_length_greater_than_4, 
        data = ClicksG0_Exact))
# Call:
#   lm(formula = RPC ~ query_length + query_length_greater_than_4, 
#      data = ClicksG0_Exact)
# 
# Residuals:
#   Min     1Q Median     3Q    Max 
# -4.293 -3.331 -2.369 -0.289 48.594 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)                   0.4439     0.7838   0.566 0.571251    
# query_length                  0.9624     0.2911   3.306 0.000973 ***
#   query_length_greater_than_4  -2.7847     1.3688  -2.034 0.042120 *  
#   ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 7.609 on 1259 degrees of freedom
# Multiple R-squared:  0.008641,	Adjusted R-squared:  0.007066 
# F-statistic: 5.487 on 2 and 1259 DF,  p-value: 0.00424


summary(lm(formula = RPC ~ query_length + query_length_greater_than_4, 
   data = ClicksG0_Google))

# Call:
#   lm(formula = RPC ~ query_length + query_length_greater_than_4, 
#      data = ClicksG0_Google)
# 
# Residuals:
#   Min     1Q Median     3Q    Max 
# -4.539 -3.520 -2.502  0.221 98.516 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)                   0.4658     0.5306   0.878  0.38011    
# query_length                  1.0182     0.2015   5.054 4.61e-07 ***
#   query_length_greater_than_4  -3.4127     1.1212  -3.044  0.00236 ** 
#   ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 7.75 on 2622 degrees of freedom
# Multiple R-squared:  0.009822,	Adjusted R-squared:  0.009067 
# F-statistic:    13 on 2 and 2622 DF,  p-value: 2.399e-06

summary(lm(formula = RPC ~ query_length, 
           data = ClicksG0_Google))

# 
# Call:
#   lm(formula = RPC ~ query_length, data = ClicksG0_Google)
# 
# Residuals:
#   Min     1Q Median     3Q    Max 
# -5.478 -3.315 -2.594  0.291 98.128 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)    1.1514     0.4811   2.393   0.0168 *  
#   query_length   0.7211     0.1765   4.086 4.53e-05 ***
#   ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 7.762 on 2623 degrees of freedom
# Multiple R-squared:  0.006324,	Adjusted R-squared:  0.005945 
# F-statistic: 16.69 on 1 and 2623 DF,  p-value: 4.528e-05


summary(lm(formula = RPC ~ query_length + query_length_greater_than_4, 
          data = ClicksG0_Microsoft))

new = ClicksG0_Google %>% group_by(query_length) %>% summarise(avgCTR = mean(CTR, na.rm=T), count = n(), total=sum(CTR, na.rm=T))
new
new_1 = ClicksG0_Google %>% group_by(query_length) %>% summarise(avgCTR = mean(CTR, na.rm=T))# count = n())
new_1
plot(new_1)

new = ClicksG0_Microsoft %>% group_by(query_length) %>% summarise(avgCTR = mean(CTR, na.rm=T), count = n(), total=sum(CTR, na.rm=T))
new
new_1 = ClicksG0_Microsoft %>% group_by(query_length) %>% summarise(avgCTR = mean(CTR, na.rm=T))# count = n())
new_1
plot(new_1)


new = ClicksG0_Yahoo %>% group_by(query_length) %>% summarise(avgCTR = mean(CTR, na.rm=T), count = n(), total=sum(CTR, na.rm=T))
new
new_1 = ClicksG0_Yahoo %>% group_by(query_length) %>% summarise(avgCTR = mean(CTR, na.rm=T))# count = n())
new_1
plot(new_1)

summary(lm(formula = CTR ~ query_length , 
           data = ClicksG0_Google))

# Call:
#   lm(formula = CTR ~ query_length, data = ClicksG0_Google)
# 
# Residuals:
#   Min       1Q   Median       3Q      Max 
# -0.16776 -0.10419 -0.07441 -0.00238  0.93214 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)   0.194857   0.012219  15.948  < 2e-16 ***
#   query_length -0.025400   0.004482  -5.667 1.61e-08 ***
#   ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 0.1971 on 2623 degrees of freedom
# Multiple R-squared:  0.0121,	Adjusted R-squared:  0.01172 
# F-statistic: 32.11 on 1 and 2623 DF,  p-value: 1.612e-08

summary(lm(formula = CTR ~ query_length + query_length_greater_than_4, 
           data = ClicksG0_Google))

# Call:
#   lm(formula = CTR ~ query_length + query_length_greater_than_4, 
#      data = ClicksG0_Google)
# 
# Residuals:
#   Min       1Q   Median       3Q      Max 
# -0.17438 -0.10365 -0.07394 -0.00403  0.91532 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)                  0.206555   0.013487  15.315  < 2e-16 ***
#   query_length                -0.030470   0.005121  -5.950 3.03e-09 ***
#   query_length_greater_than_4  0.058231   0.028501   2.043   0.0411 *  
#   ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 0.197 on 2622 degrees of freedom
# Multiple R-squared:  0.01367,	Adjusted R-squared:  0.01291 
# F-statistic: 18.16 on 2 and 2622 DF,  p-value: 1.464e-08


summary(lm(formula = CTR ~ query_length + query_length_greater_than_4, 
             data = ClicksG0_Google_Broad))

# Call:
#   lm(formula = CTR ~ query_length + query_length_greater_than_4, 
#      data = ClicksG0_Google_Broad)
# 
# Residuals:
#   Min       1Q   Median       3Q      Max 
# -0.14770 -0.07295 -0.04257 -0.00218  0.93241 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)                  0.194404   0.015252  12.746  < 2e-16 ***
#   query_length                -0.042271   0.005762  -7.337 4.21e-13 ***
#   query_length_greater_than_4  0.095198   0.048742   1.953   0.0511 .  
# ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 0.1521 on 1111 degrees of freedom
# Multiple R-squared:  0.04638,	Adjusted R-squared:  0.04466 
# F-statistic: 27.02 on 2 and 1111 DF,  p-value: 3.492e-12



> summary(lm(formula = CTR ~ query_length + query_length_greater_than_4, 
             +            data = ClicksG0_Yahoo_Broad))

# Call:
#   lm(formula = CTR ~ query_length + query_length_greater_than_4, 
#      data = ClicksG0_Yahoo_Broad)
# 
# Residuals:
#   Min        1Q    Median        3Q       Max 
# -0.028389 -0.010892 -0.008153  0.008077  0.081663 
# 
# Coefficients: (1 not defined because of singularities)
# Estimate Std. Error t value Pr(>|t|)    
# (Intercept)                 -0.014579   0.008839  -1.649 0.103750    
# query_length                 0.014676   0.003807   3.855 0.000262 ***
#   query_length_greater_than_4        NA         NA      NA       NA    
# ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 0.02025 on 67 degrees of freedom
# Multiple R-squared:  0.1816,	Adjusted R-squared:  0.1693 
# F-statistic: 14.86 on 1 and 67 DF,  p-value: 0.0002618


ClicksG0_Microsoft_Phrase  <- ClicksG0_Microsoft[which(ClicksG0_Microsoft$Listing.Match.Type =='Phrase'),]


# Call:
#   lm(formula = CTR ~ query_length + query_length_greater_than_4, 
#      data = ClicksG0_Microsoft_Phrase)
# 
# Residuals:
#   Min       1Q   Median       3Q      Max 
# -0.31434 -0.06369 -0.04226  0.00581  0.92889 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)   
# (Intercept)                 -0.03968    0.04284  -0.926  0.35551   
# query_length                 0.05539    0.01705   3.248  0.00137 **
#   query_length_greater_than_4  0.14554    0.10976   1.326  0.18642   
# ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 0.1726 on 193 degrees of freedom
# Multiple R-squared:  0.08898,	Adjusted R-squared:  0.07954 
# F-statistic: 9.425 on 2 and 193 DF,  p-value: 0.0001243
# 
# 
# 
# > summary(lm(formula = CTR ~ query_length + query_length_greater_than_4, 
#              +            data = ClicksG0_Google_Broad))
# 
# Call:
#   lm(formula = CTR ~ query_length + query_length_greater_than_4, 
#      data = ClicksG0_Google_Broad)
# 
# Residuals:
#   Min       1Q   Median       3Q      Max 
# -0.14770 -0.07295 -0.04257 -0.00218  0.93241 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)                  0.194404   0.015252  12.746  < 2e-16 ***
#   query_length                -0.042271   0.005762  -7.337 4.21e-13 ***
#   query_length_greater_than_4  0.095198   0.048742   1.953   0.0511 .  
# ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 0.1521 on 1111 degrees of freedom
# Multiple R-squared:  0.04638,	Adjusted R-squared:  0.04466 
# F-statistic: 27.02 on 2 and 1111 DF,  p-value: 3.492e-12
# 
# > summary(lm(formula = CTR ~ query_length + query_length_greater_than_4, 
#              +            data = ClicksG0_Yahoo_Broad))
# 
# Call:
#   lm(formula = CTR ~ query_length + query_length_greater_than_4, 
#      data = ClicksG0_Yahoo_Broad)
# 
# Residuals:
#   Min        1Q    Median        3Q       Max 
# -0.028389 -0.010892 -0.008153  0.008077  0.081663 
# 
# Coefficients: (1 not defined because of singularities)
# Estimate Std. Error t value Pr(>|t|)    
# (Intercept)                 -0.014579   0.008839  -1.649 0.103750    
# query_length                 0.014676   0.003807   3.855 0.000262 ***
#   query_length_greater_than_4        NA         NA      NA       NA    
# ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 0.02025 on 67 degrees of freedom
# Multiple R-squared:  0.1816,	Adjusted R-squared:  0.1693 
# F-statistic: 14.86 on 1 and 67 DF,  p-value: 0.0002618
# 
# > 
#   > 
#   > 
#   > summary(lm(formula = CTR ~ query_length + query_length_greater_than_4, 
#                +            data = ClicksG0_Microsoft_Phrase))
# Error in is.data.frame(data) : 
#   object 'ClicksG0_Microsoft_Phrase' not found
# > ClicksG0_Microsoft_Phrase  <- ClicksG0_Microsoft[which(ClicksG0_Microsoft$Listing.Match.Type =='Phrase'),]
# > summary(lm(formula = CTR ~ query_length + query_length_greater_than_4, 
#              +            data = ClicksG0_Microsoft_Phrase))
# 
# Call:
#   lm(formula = CTR ~ query_length + query_length_greater_than_4, 
#      data = ClicksG0_Microsoft_Phrase)
# 
# Residuals:
#   Min       1Q   Median       3Q      Max 
# -0.31434 -0.06369 -0.04226  0.00581  0.92889 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)   
# (Intercept)                 -0.03968    0.04284  -0.926  0.35551   
# query_length                 0.05539    0.01705   3.248  0.00137 **
#   query_length_greater_than_4  0.14554    0.10976   1.326  0.18642   
# ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 0.1726 on 193 degrees of freedom
# Multiple R-squared:  0.08898,	Adjusted R-squared:  0.07954 
# F-statistic: 9.425 on 2 and 193 DF,  p-value: 0.0001243
# 
# > summary(lm(formula = CTR ~ query_length, 
#              +            data = ClicksG0_Microsoft_Phrase))
# 
# Call:
#   lm(formula = CTR ~ query_length, data = ClicksG0_Microsoft_Phrase)
# 
# Residuals:
#   Min       1Q   Median       3Q      Max 
# -0.19434 -0.06282 -0.04191  0.00763  0.93071 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)  -0.05974    0.04016  -1.488    0.138    
# query_length  0.06451    0.01563   4.126 5.47e-05 ***
#   ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 0.173 on 194 degrees of freedom
# Multiple R-squared:  0.08068,	Adjusted R-squared:  0.07594 
# F-statistic: 17.03 on 1 and 194 DF,  p-value: 5.468e-05
# 
# > summary(lm(formula = CTR ~ query_length, 
#              +            data = ClicksG0_Yahoo_Broad))
# 
# Call:
#   lm(formula = CTR ~ query_length, data = ClicksG0_Yahoo_Broad)
# 
# Residuals:
#   Min        1Q    Median        3Q       Max 
# -0.028389 -0.010892 -0.008153  0.008077  0.081663 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)  -0.014579   0.008839  -1.649 0.103750    
# query_length  0.014676   0.003807   3.855 0.000262 ***
#   ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 0.02025 on 67 degrees of freedom
# Multiple R-squared:  0.1816,	Adjusted R-squared:  0.1693 
# F-statistic: 14.86 on 1 and 67 DF,  p-value: 0.0002618
# 
# > summary(lm(formula = CTR ~ query_length, 
#              +            data = ClicksG0_Google_Broad))
# 
# Call:
#   lm(formula = CTR ~ query_length, data = ClicksG0_Google_Broad)
# 
# Residuals:
#   Min       1Q   Median       3Q      Max 
# -0.14296 -0.07168 -0.04402 -0.00416  0.92983 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)   0.186016   0.014653  12.695  < 2e-16 ***
#   query_length -0.038616   0.005456  -7.078 2.59e-12 ***
#   ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 0.1523 on 1112 degrees of freedom
# Multiple R-squared:  0.04311,	Adjusted R-squared:  0.04225 
# F-statistic: 50.09 on 1 and 1112 DF,  p-value: 2.592e-12
